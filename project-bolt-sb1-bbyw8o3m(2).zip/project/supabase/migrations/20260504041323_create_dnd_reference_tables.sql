/*
  # Create D&D Reference Tables

  1. New Tables
    - `dnd_creatures` - Monsters and NPCs from D&D.su
      - `id` (uuid, primary key)
      - `name` (text)
      - `type` (text) - creature type
      - `challenge` (numeric) - CR
      - `ac` (numeric) - armor class
      - `hp` (text) - hit points description
      - `speed` (text)
      - `abilities` (text) - JSON with ability scores
      - `skills` (text)
      - `senses` (text)
      - `languages` (text)
      - `traits` (text) - JSON array
      - `actions` (text) - JSON array
      - `reactions` (text) - JSON array
      - `description` (text)
      
    - `dnd_items` - Magic items and equipment
      - `id` (uuid, primary key)
      - `name` (text)
      - `rarity` (text)
      - `type` (text)
      - `attunement` (boolean)
      - `description` (text)
      - `properties` (text) - JSON
      
    - `dnd_spells` - Spell reference
      - `id` (uuid, primary key)
      - `name` (text)
      - `level` (numeric)
      - `school` (text)
      - `casting_time` (text)
      - `range` (text)
      - `components` (text)
      - `duration` (text)
      - `description` (text)
      - `classes` (text)

  2. Security
    - Enable RLS on all tables
    - Allow public read access (anyone can view reference data)
*/

CREATE TABLE IF NOT EXISTS dnd_creatures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text,
  challenge numeric,
  ac numeric,
  hp text,
  speed text,
  abilities text,
  skills text,
  senses text,
  languages text,
  traits text,
  actions text,
  reactions text,
  description text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dnd_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  rarity text,
  type text,
  attunement boolean DEFAULT false,
  description text,
  properties text,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS dnd_spells (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  level numeric,
  school text,
  casting_time text,
  range text,
  components text,
  duration text,
  description text,
  classes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE dnd_creatures ENABLE ROW LEVEL SECURITY;
ALTER TABLE dnd_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE dnd_spells ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read creatures"
  ON dnd_creatures FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can read items"
  ON dnd_items FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can read spells"
  ON dnd_spells FOR SELECT
  TO public
  USING (true);
