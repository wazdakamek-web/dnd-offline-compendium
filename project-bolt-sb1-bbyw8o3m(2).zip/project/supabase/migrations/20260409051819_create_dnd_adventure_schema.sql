/*
  # DnD Adventure Flowchart Application Schema

  ## Overview
  Creates all tables needed for the DnD Adventure Flowchart builder application.

  ## New Tables
  1. `projects` - Adventure projects with names and descriptions
  2. `blocks` - Flowchart nodes/blocks with position, label, and color
  3. `connections` - Directed arrows between blocks with optional labels
  4. `block_contents` - Rich content (text/images) on block detail pages

  ## Security
  - RLS enabled on all tables
  - Public (anon) access granted since this app has no user authentication
  - All CRUD operations allowed for anonymous users

  ## Notes
  - Blocks and connections cascade-delete when their project is deleted
  - Block contents cascade-delete when their block is deleted
  - Connection labels support branching path descriptions
*/

CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  label text NOT NULL DEFAULT 'Новый блок',
  x float NOT NULL DEFAULT 100,
  y float NOT NULL DEFAULT 100,
  color text NOT NULL DEFAULT '#1e3a5f',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS connections (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  from_block_id uuid NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
  to_block_id uuid NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
  label text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS block_contents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  block_id uuid NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('text', 'image')),
  content text NOT NULL DEFAULT '',
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE connections ENABLE ROW LEVEL SECURITY;
ALTER TABLE block_contents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public select projects" ON projects FOR SELECT TO anon USING (true);
CREATE POLICY "Public insert projects" ON projects FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Public update projects" ON projects FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Public delete projects" ON projects FOR DELETE TO anon USING (true);

CREATE POLICY "Public select blocks" ON blocks FOR SELECT TO anon USING (true);
CREATE POLICY "Public insert blocks" ON blocks FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Public update blocks" ON blocks FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Public delete blocks" ON blocks FOR DELETE TO anon USING (true);

CREATE POLICY "Public select connections" ON connections FOR SELECT TO anon USING (true);
CREATE POLICY "Public insert connections" ON connections FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Public update connections" ON connections FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Public delete connections" ON connections FOR DELETE TO anon USING (true);

CREATE POLICY "Public select block_contents" ON block_contents FOR SELECT TO anon USING (true);
CREATE POLICY "Public insert block_contents" ON block_contents FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Public update block_contents" ON block_contents FOR UPDATE TO anon USING (true) WITH CHECK (true);
CREATE POLICY "Public delete block_contents" ON block_contents FOR DELETE TO anon USING (true);
