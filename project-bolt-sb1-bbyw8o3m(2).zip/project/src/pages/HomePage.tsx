import { useEffect, useState } from 'react';
import { Project, AppView } from '../lib/types';
import { db_projects, db_characters, initDb, Character, db_dnd, DndCreature, DndItem, DndSpell } from '../lib/db';
import { Search, X, BookOpen } from 'lucide-react';

interface Props {
  onNavigate: (view: AppView) => void;
}

export default function HomePage({ onNavigate }: Props) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [error, setError] = useState('');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [deleteCharConfirm, setDeleteCharConfirm] = useState<string | null>(null);
  const [showDndMenu, setShowDndMenu] = useState(false);
  const [diceResults, setDiceResults] = useState<{ dice: number; result: number }[]>([]);
  const [showDndReference, setShowDndReference] = useState(false);
  const [dndTab, setDndTab] = useState<'creatures' | 'items' | 'spells'>('creatures');
  const [dndSearchQuery, setDndSearchQuery] = useState('');
  const [dndCreatures, setDndCreatures] = useState<DndCreature[]>([]);
  const [dndItems, setDndItems] = useState<DndItem[]>([]);
  const [dndSpells, setDndSpells] = useState<DndSpell[]>([]);
  const [selectedCreature, setSelectedCreature] = useState<DndCreature | null>(null);
  const [selectedItem, setSelectedItem] = useState<DndItem | null>(null);
  const [selectedSpell, setSelectedSpell] = useState<DndSpell | null>(null);
  const [dndLoading, setDndLoading] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  async function loadData() {
    setLoading(true);
    await initDb();
    const projData = await db_projects.getAll();
    const charData = await db_characters.getAll();
    setProjects(projData || []);
    setCharacters(charData || []);
    setLoading(false);
  }

  async function loadProjects() {
    await loadData();
  }

  async function createProject() {
    if (!newName.trim()) { setError('Введите название проекта'); return; }
    try {
      const data = await db_projects.create({ name: newName.trim(), description: newDesc.trim() });
      setCreating(false);
      setNewName('');
      setNewDesc('');
      setError('');
      onNavigate({ type: 'flowchart', projectId: data.id });
    } catch (err) {
      setError('Ошибка создания проекта');
    }
  }

  async function deleteProject(id: string) {
    try {
      await db_projects.delete(id);
      setProjects(prev => prev.filter(p => p.id !== id));
      setDeleteConfirm(null);
    } catch (err) {
      alert('Ошибка удаления проекта');
    }
  }

  async function deleteCharacter(id: string) {
    try {
      await db_characters.delete(id);
      setCharacters(prev => prev.filter(c => c.id !== id));
      setDeleteCharConfirm(null);
    } catch (err) {
      alert('Ошибка удаления персонажа');
    }
  }

  function formatDate(dateStr: string) {
    return new Date(dateStr).toLocaleDateString('ru-RU', {
      day: '2-digit', month: 'long', year: 'numeric',
    });
  }

  function rollDice(sides: number) {
    const result = Math.floor(Math.random() * sides) + 1;
    setDiceResults(prev => [...prev, { dice: sides, result }]);
  }

  async function loadDndData(query: string = '') {
    setDndLoading(true);
    try {
      if (dndTab === 'creatures') {
        const data = query ? await db_dnd.creatures.search(query) : await db_dnd.creatures.getAll();
        setDndCreatures(data);
      } else if (dndTab === 'items') {
        const data = query ? await db_dnd.items.search(query) : await db_dnd.items.getAll();
        setDndItems(data);
      } else {
        const data = query ? await db_dnd.spells.search(query) : await db_dnd.spells.getAll();
        setDndSpells(data);
      }
    } catch (err) {
      console.error('Error loading D&D data:', err);
    }
    setDndLoading(false);
  }

  async function handleDndTabChange(tab: 'creatures' | 'items' | 'spells') {
    setDndTab(tab);
    setDndSearchQuery('');
    setSelectedCreature(null);
    setSelectedItem(null);
    setSelectedSpell(null);
  }

  async function handleDndSearch(query: string) {
    setDndSearchQuery(query);
    if (query.length > 2) {
      await loadDndData(query);
    } else if (query.length === 0) {
      await loadDndData('');
    }
  }

  async function openDndReference() {
    setShowDndReference(true);
    if (dndCreatures.length === 0) {
      await loadDndData('');
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      background: '#0c0a09',
      backgroundImage: 'radial-gradient(ellipse at 50% 0%, rgba(217,119,6,0.08) 0%, transparent 60%)',
    }}>
      <div style={{
        maxWidth: 900, margin: '0 auto', padding: '60px 24px 80px',
      }}>
        <div style={{ textAlign: 'center', marginBottom: 60 }}>
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 10,
            background: 'rgba(217,119,6,0.1)', border: '1px solid rgba(217,119,6,0.3)',
            borderRadius: 100, padding: '4px 16px', marginBottom: 24,
          }}>
            <span style={{ color: '#d97706', fontSize: 12, fontFamily: 'Georgia, serif', letterSpacing: 2 }}>
              DUNGEON MASTER TOOLKIT
            </span>
            <div style={{ position: 'relative', marginLeft: 8, paddingLeft: 8, borderLeft: '1px solid rgba(217,119,6,0.3)' }}>
              <button
                onClick={() => setShowDndMenu(!showDndMenu)}
                style={{
                  background: 'transparent', border: 'none',
                  color: '#d97706', fontSize: 12, fontFamily: 'Georgia, serif',
                  textDecoration: 'none', transition: 'color 0.2s', cursor: 'pointer',
                  padding: 0,
                }}
                onMouseEnter={e => (e.currentTarget as HTMLButtonElement).style.color = '#f59e0b'}
                onMouseLeave={e => !showDndMenu && ((e.currentTarget as HTMLButtonElement).style.color = '#d97706')}
              >
                dnd.su ↗
              </button>
              {showDndMenu && (
                <div
                  style={{
                    position: 'absolute', top: 24, left: 0, zIndex: 100,
                    background: '#1c1917', border: '1px solid #44403c',
                    borderRadius: 8, minWidth: 240, boxShadow: '0 8px 32px rgba(0,0,0,0.8)',
                    overflow: 'hidden',
                  }}
                  onMouseLeave={() => setShowDndMenu(false)}
                >
                  <a
                    href="https://dnd.su/encounter_difficulty/"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: 'block', padding: '10px 16px',
                      color: '#d4b896', fontSize: 12, fontFamily: 'Georgia, serif',
                      textDecoration: 'none', borderBottom: '1px solid #292524',
                      transition: 'background 0.2s',
                    }}
                    onMouseEnter={e => (e.currentTarget as HTMLAnchorElement).style.background = 'rgba(217,119,6,0.1)'}
                    onMouseLeave={e => (e.currentTarget as HTMLAnchorElement).style.background = 'transparent'}
                  >
                    ⚔ Калькулятор боёв
                  </a>
                  <a
                    href="https://dnd.su/bestiary/"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: 'block', padding: '10px 16px',
                      color: '#d4b896', fontSize: 12, fontFamily: 'Georgia, serif',
                      textDecoration: 'none', borderBottom: '1px solid #292524',
                      transition: 'background 0.2s',
                    }}
                    onMouseEnter={e => (e.currentTarget as HTMLAnchorElement).style.background = 'rgba(217,119,6,0.1)'}
                    onMouseLeave={e => (e.currentTarget as HTMLAnchorElement).style.background = 'transparent'}
                  >
                    🐉 Бестиарий
                  </a>
                  <a
                    href="https://dnd.su/items/"
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{
                      display: 'block', padding: '10px 16px',
                      color: '#d4b896', fontSize: 12, fontFamily: 'Georgia, serif',
                      textDecoration: 'none',
                      transition: 'background 0.2s',
                    }}
                    onMouseEnter={e => (e.currentTarget as HTMLAnchorElement).style.background = 'rgba(217,119,6,0.1)'}
                    onMouseLeave={e => (e.currentTarget as HTMLAnchorElement).style.background = 'transparent'}
                  >
                    ✨ Магические предметы
                  </a>
                </div>
              )}
            </div>
          </div>
          <h1 style={{
            fontSize: 52, fontFamily: 'Georgia, serif', fontWeight: 700,
            color: '#fef3c7', margin: '0 0 16px',
            textShadow: '0 2px 20px rgba(217,119,6,0.3)',
            lineHeight: 1.2,
          }}>
            Карта Приключений
          </h1>
          <p style={{
            color: '#78716c', fontSize: 16, fontFamily: 'Georgia, serif',
            lineHeight: 1.6, maxWidth: 480, margin: '0 auto',
          }}>
            Создавайте разветвлённые сюжеты для D&D с блок-схемами,
            описаниями сцен и иллюстрациями
          </p>
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 28 }}>
          <h2 style={{ color: '#d4b896', fontSize: 18, fontFamily: 'Georgia, serif', margin: 0 }}>
            Приключения
          </h2>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <button
              onClick={openDndReference}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '10px 22px',
                background: 'linear-gradient(135deg, #059669, #047857)',
                color: '#ecf0f1', border: 'none', borderRadius: 8,
                fontSize: 14, fontFamily: 'Georgia, serif', fontWeight: 700,
                cursor: 'pointer',
                boxShadow: '0 4px 16px rgba(5, 150, 105, 0.3)',
              }}
            >
              <BookOpen size={18} /> Справочник
            </button>
            <button
              onClick={() => setCreating(true)}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '10px 22px',
                background: 'linear-gradient(135deg, #d97706, #b45309)',
                color: '#1c1917', border: 'none', borderRadius: 8,
                fontSize: 14, fontFamily: 'Georgia, serif', fontWeight: 700,
                cursor: 'pointer',
                boxShadow: '0 4px 16px rgba(217,119,6,0.3)',
              }}
            >
              + Новый проект
            </button>
            <button
              onClick={() => onNavigate({ type: 'character-sheet' })}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '10px 22px',
                background: 'linear-gradient(135deg, #3b82f6, #1e40af)',
                color: '#ecf0f1', border: 'none', borderRadius: 8,
                fontSize: 14, fontFamily: 'Georgia, serif', fontWeight: 700,
                cursor: 'pointer',
                boxShadow: '0 4px 16px rgba(59,130,246,0.3)',
              }}
            >
              + Новый персонаж
            </button>
            </div>
        </div>

        {loading ? (
          <div style={{ textAlign: 'center', padding: 60, color: '#57534e', fontFamily: 'Georgia, serif' }}>
            Загрузка...
          </div>
        ) : projects.length === 0 ? (
          <div style={{
            textAlign: 'center', padding: 60,
            border: '2px dashed #292524', borderRadius: 12,
          }}>
            <div style={{ fontSize: 48, marginBottom: 16 }}>⚔️</div>
            <p style={{ color: '#57534e', fontFamily: 'Georgia, serif', fontSize: 16 }}>
              Нет проектов. Создайте своё первое приключение!
            </p>
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 }}>
            {projects.map(project => (
              <div
                key={project.id}
                style={{
                  background: 'rgba(255,255,255,0.03)',
                  border: '1px solid #292524',
                  borderRadius: 12, padding: 20,
                  cursor: 'pointer',
                  transition: 'all 0.2s',
                  position: 'relative',
                }}
                onMouseEnter={e => {
                  (e.currentTarget as HTMLDivElement).style.borderColor = '#44403c';
                  (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.05)';
                }}
                onMouseLeave={e => {
                  (e.currentTarget as HTMLDivElement).style.borderColor = '#292524';
                  (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.03)';
                }}
                onClick={() => onNavigate({ type: 'flowchart', projectId: project.id })}
              >
                <div style={{
                  width: 8, height: 8, borderRadius: '50%',
                  background: '#d97706', marginBottom: 12,
                }} />
                <h3 style={{
                  color: '#fef3c7', fontSize: 17, fontFamily: 'Georgia, serif',
                  fontWeight: 700, margin: '0 0 6px', paddingRight: 28,
                }}>
                  {project.name}
                </h3>
                {project.description && (
                  <p style={{
                    color: '#78716c', fontSize: 13, fontFamily: 'Georgia, serif',
                    margin: '0 0 12px', lineHeight: 1.5,
                  }}>
                    {project.description}
                  </p>
                )}
                <span style={{ color: '#57534e', fontSize: 12, fontFamily: 'Georgia, serif' }}>
                  {formatDate(project.updated_at)}
                </span>
                <button
                  onClick={e => { e.stopPropagation(); setDeleteConfirm(project.id); }}
                  style={{
                    position: 'absolute', top: 12, right: 12,
                    background: 'transparent', border: 'none',
                    color: '#57534e', cursor: 'pointer', fontSize: 14,
                    padding: 4, borderRadius: 4,
                  }}
                  title="Удалить проект"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

        <div style={{ marginTop: 60 }}>
          <h2 style={{ color: '#d4b896', fontSize: 18, fontFamily: 'Georgia, serif', margin: '0 0 28px' }}>
            Кидание костей
          </h2>
          <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid #292524', borderRadius: 12, padding: 24, marginBottom: 60 }}>
            <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 20 }}>
              {[4, 6, 8, 12, 20, 100].map(sides => (
                <button
                  key={sides}
                  onClick={() => rollDice(sides)}
                  style={{
                    padding: '12px 24px',
                    background: 'rgba(217,119,6,0.15)',
                    color: '#d97706',
                    border: '1px solid rgba(217,119,6,0.3)',
                    borderRadius: 8,
                    cursor: 'pointer',
                    fontSize: 14,
                    fontFamily: 'Georgia, serif',
                    fontWeight: 700,
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLButtonElement).style.background = 'rgba(217,119,6,0.25)';
                    (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(217,119,6,0.5)';
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLButtonElement).style.background = 'rgba(217,119,6,0.15)';
                    (e.currentTarget as HTMLButtonElement).style.borderColor = 'rgba(217,119,6,0.3)';
                  }}
                >
                  d{sides}
                </button>
              ))}
            </div>
            {diceResults.length > 0 && (
              <div>
                <div style={{ color: '#78716c', fontSize: 12, fontFamily: 'Georgia, serif', marginBottom: 12, letterSpacing: 1 }}>
                  РЕЗУЛЬТАТЫ
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginBottom: diceResults.length > 3 ? 12 : 0 }}>
                  {diceResults.slice(-12).map((roll, idx) => (
                    <div
                      key={idx}
                      style={{
                        background: 'linear-gradient(135deg, #d97706, #b45309)',
                        color: '#1c1917',
                        padding: '8px 14px',
                        borderRadius: 6,
                        fontFamily: 'monospace',
                        fontWeight: 700,
                        fontSize: 14,
                      }}
                    >
                      d{roll.dice}: <span style={{ color: '#fef3c7' }}>{roll.result}</span>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => setDiceResults([])}
                  style={{
                    padding: '6px 12px',
                    background: 'rgba(255,255,255,0.05)',
                    color: '#78716c',
                    border: '1px solid #292524',
                    borderRadius: 6,
                    cursor: 'pointer',
                    fontSize: 12,
                    fontFamily: 'Georgia, serif',
                  }}
                >
                  Очистить
                </button>
              </div>
            )}
          </div>
        </div>

        {characters.length > 0 && (
          <div>
            <h2 style={{ color: '#d4b896', fontSize: 18, fontFamily: 'Georgia, serif', margin: '0 0 28px' }}>
              Персонажи
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: 16 }}>
              {characters.map(character => (
                <div
                  key={character.id}
                  style={{
                    background: 'rgba(255,255,255,0.03)',
                    border: '1px solid #292524',
                    borderRadius: 12, padding: 20,
                    cursor: 'pointer',
                    transition: 'all 0.2s',
                    position: 'relative',
                  }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLDivElement).style.borderColor = '#44403c';
                    (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.05)';
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLDivElement).style.borderColor = '#292524';
                    (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.03)';
                  }}
                  onClick={() => onNavigate({ type: 'character-sheet', characterId: character.id })}
                >
                  <div style={{
                    width: 8, height: 8, borderRadius: '50%',
                    background: '#60a5fa', marginBottom: 12,
                  }} />
                  <h3 style={{
                    color: '#fef3c7', fontSize: 17, fontFamily: 'Georgia, serif',
                    fontWeight: 700, margin: '0 0 6px', paddingRight: 28,
                  }}>
                    {character.name}
                  </h3>
                  <div style={{ color: '#78716c', fontSize: 13, fontFamily: 'Georgia, serif', marginBottom: 6 }}>
                    {character.class} {character.race} 🎲 {character.level}
                  </div>
                  <span style={{ color: '#57534e', fontSize: 12, fontFamily: 'Georgia, serif' }}>
                    {formatDate(character.updated_at)}
                  </span>
                  <button
                    onClick={e => { e.stopPropagation(); setDeleteCharConfirm(character.id); }}
                    style={{
                      position: 'absolute', top: 12, right: 12,
                      background: 'transparent', border: 'none',
                      color: '#57534e', cursor: 'pointer', fontSize: 14,
                      padding: 4, borderRadius: 4,
                    }}
                    title="Удалить персонажа"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {creating && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200,
        }}>
          <div style={{
            background: '#1c1917', border: '1px solid #d97706',
            borderRadius: 14, padding: 36, width: 420, maxWidth: '90vw',
            boxShadow: '0 24px 80px rgba(0,0,0,0.9)',
          }}>
            <h2 style={{ color: '#fef3c7', fontFamily: 'Georgia, serif', margin: '0 0 24px', fontSize: 20 }}>
              Новое приключение
            </h2>
            <label style={{ display: 'block', marginBottom: 16 }}>
              <span style={{ color: '#78716c', fontSize: 12, fontFamily: 'Georgia, serif', letterSpacing: 1, display: 'block', marginBottom: 6 }}>
                НАЗВАНИЕ ПРОЕКТА *
              </span>
              <input
                autoFocus
                value={newName}
                onChange={e => { setNewName(e.target.value); setError(''); }}
                onKeyDown={e => e.key === 'Enter' && createProject()}
                placeholder="Например: Затерянные копи Фарруха..."
                style={{
                  width: '100%', background: '#0c0a09', border: `1px solid ${error ? '#ef4444' : '#44403c'}`,
                  borderRadius: 6, color: '#fef3c7', padding: '10px 14px',
                  fontSize: 15, fontFamily: 'Georgia, serif', outline: 'none',
                  boxSizing: 'border-box',
                }}
              />
              {error && <span style={{ color: '#ef4444', fontSize: 12, marginTop: 4, display: 'block' }}>{error}</span>}
            </label>
            <label style={{ display: 'block', marginBottom: 24 }}>
              <span style={{ color: '#78716c', fontSize: 12, fontFamily: 'Georgia, serif', letterSpacing: 1, display: 'block', marginBottom: 6 }}>
                ОПИСАНИЕ (необязательно)
              </span>
              <textarea
                value={newDesc}
                onChange={e => setNewDesc(e.target.value)}
                placeholder="Краткое описание приключения..."
                rows={3}
                style={{
                  width: '100%', background: '#0c0a09', border: '1px solid #44403c',
                  borderRadius: 6, color: '#fef3c7', padding: '10px 14px',
                  fontSize: 14, fontFamily: 'Georgia, serif', outline: 'none',
                  resize: 'none', boxSizing: 'border-box', lineHeight: 1.5,
                }}
              />
            </label>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button
                onClick={() => { setCreating(false); setNewName(''); setNewDesc(''); setError(''); }}
                style={{ padding: '10px 20px', background: 'transparent', color: '#78716c', border: '1px solid #44403c', borderRadius: 6, cursor: 'pointer', fontFamily: 'Georgia, serif' }}
              >
                Отмена
              </button>
              <button
                onClick={createProject}
                style={{ padding: '10px 24px', background: '#d97706', color: '#1c1917', border: 'none', borderRadius: 6, cursor: 'pointer', fontFamily: 'Georgia, serif', fontWeight: 700, fontSize: 15 }}
              >
                Создать
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200,
        }}>
          <div style={{
            background: '#1c1917', border: '1px solid #7f1d1d',
            borderRadius: 14, padding: 32, width: 360, maxWidth: '90vw',
            boxShadow: '0 24px 80px rgba(0,0,0,0.9)',
          }}>
            <h2 style={{ color: '#fca5a5', fontFamily: 'Georgia, serif', margin: '0 0 12px', fontSize: 18 }}>
              Удалить проект?
            </h2>
            <p style={{ color: '#78716c', fontFamily: 'Georgia, serif', margin: '0 0 24px', lineHeight: 1.5 }}>
              Это действие нельзя отменить. Все блоки, соединения и контент будут удалены.
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button onClick={() => setDeleteConfirm(null)} style={{ padding: '8px 18px', background: 'transparent', color: '#78716c', border: '1px solid #44403c', borderRadius: 6, cursor: 'pointer', fontFamily: 'Georgia, serif' }}>
                Отмена
              </button>
              <button onClick={() => deleteProject(deleteConfirm)} style={{ padding: '8px 18px', background: '#7f1d1d', color: '#fca5a5', border: '1px solid #ef4444', borderRadius: 6, cursor: 'pointer', fontFamily: 'Georgia, serif', fontWeight: 700 }}>
                Удалить
              </button>
            </div>
          </div>
        </div>
      )}

      {deleteCharConfirm && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200,
        }}>
          <div style={{
            background: '#1c1917', border: '1px solid #7f1d1d',
            borderRadius: 14, padding: 32, width: 360, maxWidth: '90vw',
            boxShadow: '0 24px 80px rgba(0,0,0,0.9)',
          }}>
            <h2 style={{ color: '#fca5a5', fontFamily: 'Georgia, serif', margin: '0 0 12px', fontSize: 18 }}>
              Удалить персонажа?
            </h2>
            <p style={{ color: '#78716c', fontFamily: 'Georgia, serif', margin: '0 0 24px', lineHeight: 1.5 }}>
              Это действие нельзя отменить.
            </p>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button onClick={() => setDeleteCharConfirm(null)} style={{ padding: '8px 18px', background: 'transparent', color: '#78716c', border: '1px solid #44403c', borderRadius: 6, cursor: 'pointer', fontFamily: 'Georgia, serif' }}>
                Отмена
              </button>
              <button onClick={() => deleteCharacter(deleteCharConfirm)} style={{ padding: '8px 18px', background: '#7f1d1d', color: '#fca5a5', border: '1px solid #ef4444', borderRadius: 6, cursor: 'pointer', fontFamily: 'Georgia, serif', fontWeight: 700 }}>
                Удалить
              </button>
            </div>
          </div>
        </div>
      )}

      {showDndReference && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.9)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 300,
        }}>
          <div style={{
            background: '#1c1917', border: '1px solid #292524',
            borderRadius: 14, width: '90vw', maxWidth: 900, maxHeight: '85vh',
            display: 'flex', flexDirection: 'column',
            boxShadow: '0 24px 80px rgba(0,0,0,0.95)',
          }}>
            <div style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '20px 24px', borderBottom: '1px solid #292524',
              flexShrink: 0,
            }}>
              <h2 style={{ color: '#fef3c7', fontFamily: 'Georgia, serif', margin: 0, fontSize: 20, fontWeight: 700 }}>
                D&D Справочник
              </h2>
              <button
                onClick={() => { setShowDndReference(false); setSelectedCreature(null); setSelectedItem(null); setSelectedSpell(null); }}
                style={{
                  background: 'transparent', border: 'none',
                  color: '#78716c', cursor: 'pointer', fontSize: 24,
                  padding: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}
              >
                <X size={24} />
              </button>
            </div>

            {!selectedCreature && !selectedItem && !selectedSpell ? (
              <>
                <div style={{ padding: '16px 24px', display: 'flex', gap: 8, borderBottom: '1px solid #292524', flexShrink: 0 }}>
                  {['creatures', 'items', 'spells'].map(tab => (
                    <button
                      key={tab}
                      onClick={() => handleDndTabChange(tab as 'creatures' | 'items' | 'spells')}
                      style={{
                        padding: '8px 16px',
                        background: dndTab === tab ? 'rgba(217,119,6,0.2)' : 'transparent',
                        color: dndTab === tab ? '#d97706' : '#78716c',
                        border: dndTab === tab ? '1px solid rgba(217,119,6,0.4)' : '1px solid #292524',
                        borderRadius: 6,
                        cursor: 'pointer',
                        fontSize: 13,
                        fontFamily: 'Georgia, serif',
                        transition: 'all 0.2s',
                      }}
                    >
                      {tab === 'creatures' ? 'Существа' : tab === 'items' ? 'Предметы' : 'Заклинания'}
                    </button>
                  ))}
                </div>

                <div style={{ padding: '16px 24px', borderBottom: '1px solid #292524', flexShrink: 0 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, padding: '8px 12px' }}>
                    <Search size={18} style={{ color: '#78716c' }} />
                    <input
                      type="text"
                      value={dndSearchQuery}
                      onChange={e => handleDndSearch(e.target.value)}
                      placeholder="Поиск..."
                      style={{
                        flex: 1, background: 'transparent', border: 'none',
                        color: '#fef3c7', fontSize: 14, fontFamily: 'Georgia, serif',
                        outline: 'none',
                      }}
                    />
                  </div>
                </div>

                <div style={{ flex: 1, overflow: 'auto', padding: '16px 24px' }}>
                  {dndLoading ? (
                    <div style={{ textAlign: 'center', padding: 40, color: '#78716c', fontFamily: 'Georgia, serif' }}>
                      Загрузка...
                    </div>
                  ) : dndTab === 'creatures' && dndCreatures.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: 40, color: '#57534e', fontFamily: 'Georgia, serif' }}>
                      Нет существ. Начните с поиска.
                    </div>
                  ) : dndTab === 'items' && dndItems.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: 40, color: '#57534e', fontFamily: 'Georgia, serif' }}>
                      Нет предметов. Начните с поиска.
                    </div>
                  ) : dndTab === 'spells' && dndSpells.length === 0 ? (
                    <div style={{ textAlign: 'center', padding: 40, color: '#57534e', fontFamily: 'Georgia, serif' }}>
                      Нет заклинаний. Начните с поиска.
                    </div>
                  ) : (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 12 }}>
                      {dndTab === 'creatures' && dndCreatures.map(creature => (
                        <div
                          key={creature.id}
                          onClick={() => setSelectedCreature(creature)}
                          style={{
                            background: 'rgba(255,255,255,0.03)',
                            border: '1px solid #292524',
                            borderRadius: 8, padding: 12,
                            cursor: 'pointer',
                            transition: 'all 0.2s',
                          }}
                          onMouseEnter={e => {
                            (e.currentTarget as HTMLDivElement).style.borderColor = '#44403c';
                            (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.05)';
                          }}
                          onMouseLeave={e => {
                            (e.currentTarget as HTMLDivElement).style.borderColor = '#292524';
                            (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.03)';
                          }}
                        >
                          <div style={{ color: '#fef3c7', fontSize: 14, fontFamily: 'Georgia, serif', fontWeight: 700, marginBottom: 4 }}>
                            {creature.name}
                          </div>
                          <div style={{ color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif' }}>
                            {creature.type} · CR {creature.challenge}
                          </div>
                        </div>
                      ))}
                      {dndTab === 'items' && dndItems.map(item => (
                        <div
                          key={item.id}
                          onClick={() => setSelectedItem(item)}
                          style={{
                            background: 'rgba(255,255,255,0.03)',
                            border: '1px solid #292524',
                            borderRadius: 8, padding: 12,
                            cursor: 'pointer',
                            transition: 'all 0.2s',
                          }}
                          onMouseEnter={e => {
                            (e.currentTarget as HTMLDivElement).style.borderColor = '#44403c';
                            (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.05)';
                          }}
                          onMouseLeave={e => {
                            (e.currentTarget as HTMLDivElement).style.borderColor = '#292524';
                            (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.03)';
                          }}
                        >
                          <div style={{ color: '#fef3c7', fontSize: 14, fontFamily: 'Georgia, serif', fontWeight: 700, marginBottom: 4 }}>
                            {item.name}
                          </div>
                          <div style={{ color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif' }}>
                            {item.rarity} · {item.type}
                          </div>
                        </div>
                      ))}
                      {dndTab === 'spells' && dndSpells.map(spell => (
                        <div
                          key={spell.id}
                          onClick={() => setSelectedSpell(spell)}
                          style={{
                            background: 'rgba(255,255,255,0.03)',
                            border: '1px solid #292524',
                            borderRadius: 8, padding: 12,
                            cursor: 'pointer',
                            transition: 'all 0.2s',
                          }}
                          onMouseEnter={e => {
                            (e.currentTarget as HTMLDivElement).style.borderColor = '#44403c';
                            (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.05)';
                          }}
                          onMouseLeave={e => {
                            (e.currentTarget as HTMLDivElement).style.borderColor = '#292524';
                            (e.currentTarget as HTMLDivElement).style.background = 'rgba(255,255,255,0.03)';
                          }}
                        >
                          <div style={{ color: '#fef3c7', fontSize: 14, fontFamily: 'Georgia, serif', fontWeight: 700, marginBottom: 4 }}>
                            {spell.name}
                          </div>
                          <div style={{ color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif' }}>
                            Уровень {spell.level} · {spell.school}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            ) : selectedCreature ? (
              <div style={{ flex: 1, overflow: 'auto', padding: '24px', display: 'flex', flexDirection: 'column' }}>
                <button
                  onClick={() => setSelectedCreature(null)}
                  style={{
                    alignSelf: 'flex-start', marginBottom: 16,
                    padding: '6px 12px',
                    background: 'rgba(255,255,255,0.05)',
                    color: '#78716c',
                    border: '1px solid #292524',
                    borderRadius: 6,
                    cursor: 'pointer',
                    fontSize: 12,
                    fontFamily: 'Georgia, serif',
                  }}
                >
                  ← Назад
                </button>
                <h3 style={{ color: '#fef3c7', fontSize: 24, fontFamily: 'Georgia, serif', fontWeight: 700, margin: '0 0 12px' }}>
                  {selectedCreature.name}
                </h3>
                <div style={{ color: '#d97706', fontSize: 12, fontFamily: 'Georgia, serif', marginBottom: 16, letterSpacing: 1 }}>
                  {selectedCreature.type} · CR {selectedCreature.challenge} · ОД {selectedCreature.ac} · ЧЗ {selectedCreature.hp}
                </div>
                {selectedCreature.description && (
                  <div style={{ color: '#fef3c7', fontSize: 14, fontFamily: 'Georgia, serif', lineHeight: 1.6, marginBottom: 16 }}>
                    {selectedCreature.description}
                  </div>
                )}
                {selectedCreature.abilities && (
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ color: '#d4b896', fontSize: 12, fontFamily: 'Georgia, serif', letterSpacing: 1, marginBottom: 8 }}>
                      ХАРАКТЕРИСТИКИ
                    </div>
                    <div style={{ color: '#78716c', fontSize: 12, fontFamily: 'Georgia, serif', lineHeight: 1.5 }}>
                      {selectedCreature.abilities}
                    </div>
                  </div>
                )}
              </div>
            ) : selectedItem ? (
              <div style={{ flex: 1, overflow: 'auto', padding: '24px', display: 'flex', flexDirection: 'column' }}>
                <button
                  onClick={() => setSelectedItem(null)}
                  style={{
                    alignSelf: 'flex-start', marginBottom: 16,
                    padding: '6px 12px',
                    background: 'rgba(255,255,255,0.05)',
                    color: '#78716c',
                    border: '1px solid #292524',
                    borderRadius: 6,
                    cursor: 'pointer',
                    fontSize: 12,
                    fontFamily: 'Georgia, serif',
                  }}
                >
                  ← Назад
                </button>
                <h3 style={{ color: '#fef3c7', fontSize: 24, fontFamily: 'Georgia, serif', fontWeight: 700, margin: '0 0 12px' }}>
                  {selectedItem.name}
                </h3>
                <div style={{ color: '#f59e0b', fontSize: 12, fontFamily: 'Georgia, serif', marginBottom: 16, letterSpacing: 1 }}>
                  {selectedItem.rarity} · {selectedItem.type} {selectedItem.attunement && '· Требует настройки'}
                </div>
                {selectedItem.description && (
                  <div style={{ color: '#fef3c7', fontSize: 14, fontFamily: 'Georgia, serif', lineHeight: 1.6 }}>
                    {selectedItem.description}
                  </div>
                )}
              </div>
            ) : selectedSpell ? (
              <div style={{ flex: 1, overflow: 'auto', padding: '24px', display: 'flex', flexDirection: 'column' }}>
                <button
                  onClick={() => setSelectedSpell(null)}
                  style={{
                    alignSelf: 'flex-start', marginBottom: 16,
                    padding: '6px 12px',
                    background: 'rgba(255,255,255,0.05)',
                    color: '#78716c',
                    border: '1px solid #292524',
                    borderRadius: 6,
                    cursor: 'pointer',
                    fontSize: 12,
                    fontFamily: 'Georgia, serif',
                  }}
                >
                  ← Назад
                </button>
                <h3 style={{ color: '#fef3c7', fontSize: 24, fontFamily: 'Georgia, serif', fontWeight: 700, margin: '0 0 12px' }}>
                  {selectedSpell.name}
                </h3>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
                  <div>
                    <div style={{ color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', letterSpacing: 1, marginBottom: 4 }}>
                      УРОВЕНЬ
                    </div>
                    <div style={{ color: '#fef3c7', fontSize: 14, fontFamily: 'Georgia, serif', fontWeight: 700 }}>
                      {selectedSpell.level === 0 ? 'Трюк' : `Уровень ${selectedSpell.level}`}
                    </div>
                  </div>
                  <div>
                    <div style={{ color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', letterSpacing: 1, marginBottom: 4 }}>
                      ШКОЛА
                    </div>
                    <div style={{ color: '#fef3c7', fontSize: 14, fontFamily: 'Georgia, serif', fontWeight: 700 }}>
                      {selectedSpell.school}
                    </div>
                  </div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
                  <div>
                    <div style={{ color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', letterSpacing: 1, marginBottom: 4 }}>
                      ВРЕМЯ ДЕЙСТВИЯ
                    </div>
                    <div style={{ color: '#fef3c7', fontSize: 13, fontFamily: 'Georgia, serif' }}>
                      {selectedSpell.casting_time}
                    </div>
                  </div>
                  <div>
                    <div style={{ color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', letterSpacing: 1, marginBottom: 4 }}>
                      ДАЛЬНОСТЬ
                    </div>
                    <div style={{ color: '#fef3c7', fontSize: 13, fontFamily: 'Georgia, serif' }}>
                      {selectedSpell.range}
                    </div>
                  </div>
                </div>
                <div style={{ marginBottom: 16 }}>
                  <div style={{ color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', letterSpacing: 1, marginBottom: 4 }}>
                    КОМПОНЕНТЫ
                  </div>
                  <div style={{ color: '#fef3c7', fontSize: 13, fontFamily: 'Georgia, serif' }}>
                    {selectedSpell.components}
                  </div>
                </div>
                <div style={{ marginBottom: 16 }}>
                  <div style={{ color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', letterSpacing: 1, marginBottom: 4 }}>
                    ДЛИТЕЛЬНОСТЬ
                  </div>
                  <div style={{ color: '#fef3c7', fontSize: 13, fontFamily: 'Georgia, serif' }}>
                    {selectedSpell.duration}
                  </div>
                </div>
                {selectedSpell.description && (
                  <div style={{ marginBottom: 16 }}>
                    <div style={{ color: '#d4b896', fontSize: 12, fontFamily: 'Georgia, serif', letterSpacing: 1, marginBottom: 8 }}>
                      ОПИСАНИЕ
                    </div>
                    <div style={{ color: '#fef3c7', fontSize: 14, fontFamily: 'Georgia, serif', lineHeight: 1.6 }}>
                      {selectedSpell.description}
                    </div>
                  </div>
                )}
              </div>
            ) : null}
          </div>
        </div>
      )}
    </div>
  );
}
