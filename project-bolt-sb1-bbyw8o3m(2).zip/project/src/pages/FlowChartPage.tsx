import { useEffect, useState } from 'react';
import { Project, Block, Connection, AppView } from '../lib/types';
import { db_projects, db_blocks, db_connections, initDb } from '../lib/db';
import FlowchartCanvas from '../components/flowchart/FlowchartCanvas';

interface Props {
  projectId: string;
  onNavigate: (view: AppView) => void;
}

export default function FlowChartPage({ projectId, onNavigate }: Props) {
  const [project, setProject] = useState<Project | null>(null);
  const [blocks, setBlocks] = useState<Block[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingName, setEditingName] = useState(false);
  const [nameValue, setNameValue] = useState('');

  useEffect(() => {
    loadData();
  }, [projectId]);

  async function loadData() {
    setLoading(true);
    await initDb();
    const proj = await db_projects.getById(projectId);
    const blks = await db_blocks.getByProject(projectId);
    const conns = await db_connections.getByProject(projectId);
    setProject(proj);
    setBlocks(blks || []);
    setConnections(conns || []);
    setNameValue(proj?.name || '');
    setLoading(false);
  }

  async function saveName() {
    setEditingName(false);
    if (!nameValue.trim() || nameValue === project?.name) return;
    try {
      await db_projects.update(projectId, { name: nameValue.trim() });
      setProject(prev => prev ? { ...prev, name: nameValue.trim() } : prev);
    } catch (err) {
      alert('Ошибка сохранения');
    }
  }

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', background: '#0c0a09', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ color: '#78716c', fontFamily: 'Georgia, serif', fontSize: 18 }}>Загрузка проекта...</div>
      </div>
    );
  }

  if (!project) {
    return (
      <div style={{ minHeight: '100vh', background: '#0c0a09', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ color: '#ef4444', fontFamily: 'Georgia, serif' }}>Проект не найден</div>
      </div>
    );
  }

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#0c0a09' }}>
      <div style={{
        display: 'flex', alignItems: 'center', gap: 16,
        padding: '10px 20px',
        background: 'rgba(0,0,0,0.8)',
        borderBottom: '1px solid #292524',
        backdropFilter: 'blur(8px)',
        flexShrink: 0,
      }}>
        <button
          onClick={() => onNavigate({ type: 'home' })}
          style={{
            display: 'flex', alignItems: 'center', gap: 6,
            padding: '6px 14px',
            background: 'rgba(255,255,255,0.04)',
            color: '#78716c', border: '1px solid #292524',
            borderRadius: 6, cursor: 'pointer',
            fontSize: 13, fontFamily: 'Georgia, serif',
            transition: 'all 0.15s',
          }}
          onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = '#d4b896'; (e.currentTarget as HTMLButtonElement).style.borderColor = '#44403c'; }}
          onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = '#78716c'; (e.currentTarget as HTMLButtonElement).style.borderColor = '#292524'; }}
        >
          ← Проекты
        </button>

        <div style={{ width: 1, height: 24, background: '#292524' }} />

        {editingName ? (
          <input
            autoFocus
            value={nameValue}
            onChange={e => setNameValue(e.target.value)}
            onBlur={saveName}
            onKeyDown={e => { if (e.key === 'Enter') saveName(); if (e.key === 'Escape') { setEditingName(false); setNameValue(project.name); } }}
            style={{
              background: 'transparent', border: 'none',
              borderBottom: '1px solid #d97706',
              color: '#fef3c7', fontSize: 17,
              fontFamily: 'Georgia, serif', fontWeight: 700,
              outline: 'none', padding: '2px 0', minWidth: 200,
            }}
          />
        ) : (
          <h1
            onClick={() => setEditingName(true)}
            title="Нажмите для редактирования"
            style={{
              margin: 0, fontSize: 17, fontFamily: 'Georgia, serif',
              fontWeight: 700, color: '#fef3c7', cursor: 'text',
            }}
          >
            {project.name}
          </h1>
        )}

        <span style={{
          background: 'rgba(217,119,6,0.1)',
          border: '1px solid rgba(217,119,6,0.2)',
          color: '#d97706', fontSize: 11,
          fontFamily: 'Georgia, serif', padding: '2px 10px',
          borderRadius: 100, letterSpacing: 1,
        }}>
          БЛОК-СХЕМА
        </span>

        <div style={{ marginLeft: 'auto', color: '#57534e', fontSize: 12, fontFamily: 'Georgia, serif' }}>
          {blocks.length} блоков · {connections.length} соединений
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'hidden' }}>
        <FlowchartCanvas
          projectId={projectId}
          blocks={blocks}
          connections={connections}
          onBlocksChange={setBlocks}
          onConnectionsChange={setConnections}
          onOpenBlock={(blockId) => onNavigate({ type: 'block', projectId, blockId })}
        />
      </div>
    </div>
  );
}
