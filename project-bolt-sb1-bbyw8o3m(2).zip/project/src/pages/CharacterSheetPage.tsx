import { useEffect, useState } from 'react';
import { Character, Spell, db_characters, initDb } from '../lib/db';
import { AppView } from '../lib/types';
import { Trash2, Plus, ChevronUp, ChevronDown } from 'lucide-react';

interface Props {
  characterId?: string;
  onNavigate: (view: AppView) => void;
}

const ABILITY_MODS = (score: number) => Math.floor((score - 10) / 2);

export default function CharacterSheetPage({ characterId, onNavigate }: Props) {
  const [character, setCharacter] = useState<Character | null>(null);
  const [loading, setLoading] = useState(true);
  const [unsaved, setUnsaved] = useState(false);

  useEffect(() => {
    loadCharacter();
  }, [characterId]);

  async function loadCharacter() {
    setLoading(true);
    await initDb();
    if (characterId) {
      const char = await db_characters.getById(characterId);
      setCharacter(char);
    } else {
      setCharacter({
        id: '',
        name: 'Новый персонаж',
        class: 'Паладин',
        race: 'Человек',
        level: 1,
        experience: 0,
        hitPoints: 10,
        maxHitPoints: 10,
        armorClass: 10,
        strength: 10,
        dexterity: 10,
        constitution: 10,
        intelligence: 10,
        wisdom: 10,
        charisma: 10,
        savesText: '',
        spells: [],
        skillsText: '',
        inventory: '',
        backstory: '',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
    }
    setUnsaved(false);
    setLoading(false);
  }

  async function saveCharacter() {
    if (!character) return;
    try {
      if (character.id) {
        await db_characters.update(character.id, character);
      } else {
        const created = await db_characters.create(character);
        setCharacter(created);
      }
      setUnsaved(false);
    } catch (err) {
      alert('Ошибка сохранения персонажа');
    }
  }

  async function deleteCharacter() {
    if (!character?.id || !confirm('Удалить персонажа?')) return;
    try {
      await db_characters.delete(character.id);
      onNavigate({ type: 'home' });
    } catch (err) {
      alert('Ошибка удаления');
    }
  }

  if (loading) {
    return <div style={{ minHeight: '100vh', background: '#0c0a09', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#78716c', fontFamily: 'Georgia, serif' }}>Загрузка...</div>;
  }

  if (!character) return null;

  const updateChar = (updates: Partial<Character>) => {
    setCharacter(prev => prev ? { ...prev, ...updates } : prev);
    setUnsaved(true);
  };

  return (
    <div style={{ minHeight: '100vh', background: '#0c0a09' }}>
      <div style={{ position: 'sticky', top: 0, zIndex: 100, background: 'rgba(12,10,9,0.95)', borderBottom: '1px solid #292524', backdropFilter: 'blur(12px)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', gap: 12, padding: '12px 24px' }}>
          <button
            onClick={() => onNavigate({ type: 'home' })}
            style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 16px', background: 'rgba(255,255,255,0.04)', color: '#78716c', border: '1px solid #292524', borderRadius: 6, cursor: 'pointer', fontSize: 13, fontFamily: 'Georgia, serif' }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = '#d4b896'; (e.currentTarget as HTMLButtonElement).style.borderColor = '#44403c'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = '#78716c'; (e.currentTarget as HTMLButtonElement).style.borderColor = '#292524'; }}
          >
            ← Назад
          </button>
          <div style={{ width: 1, height: 24, background: '#292524' }} />
          <h1 style={{ margin: 0, fontSize: 18, fontFamily: 'Georgia, serif', fontWeight: 700, color: '#fef3c7', flex: 1, minWidth: 0 }}>
            Лист персонажа
          </h1>
          <div style={{ display: 'flex', gap: 8 }}>
            <button
              onClick={saveCharacter}
              disabled={!unsaved}
              style={{ padding: '7px 16px', background: unsaved ? '#d97706' : 'rgba(255,255,255,0.02)', color: unsaved ? '#1c1917' : '#57534e', border: 'none', borderRadius: 6, cursor: unsaved ? 'pointer' : 'default', fontSize: 13, fontFamily: 'Georgia, serif', fontWeight: 700, transition: 'all 0.15s' }}
            >
              {unsaved ? '💾 Сохранить' : '✓ Сохранено'}
            </button>
            {character.id && (
              <button
                onClick={deleteCharacter}
                style={{ padding: '7px 16px', background: 'rgba(127,29,29,0.5)', color: '#fca5a5', border: '1px solid #7f1d1d', borderRadius: 6, cursor: 'pointer', fontSize: 13, fontFamily: 'Georgia, serif' }}
              >
                ✕ Удалить
              </button>
            )}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '40px 24px 80px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, marginBottom: 32 }}>
          <div>
            <h2 style={{ color: '#d4b896', fontSize: 14, fontFamily: 'Georgia, serif', letterSpacing: 1, margin: '0 0 16px', fontWeight: 600 }}>ОСНОВНЫЕ ДАННЫЕ</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <label style={{ display: 'block', color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>ИМЯ</label>
                <input value={character.name} onChange={e => updateChar({ name: e.target.value })} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 15, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }} />
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <div>
                  <label style={{ display: 'block', color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>КЛАСС</label>
                  <input value={character.class} onChange={e => updateChar({ class: e.target.value })} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 14, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }} />
                </div>
                <div>
                  <label style={{ display: 'block', color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>РАСА</label>
                  <input value={character.race} onChange={e => updateChar({ race: e.target.value })} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 14, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }} />
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <div>
                  <label style={{ display: 'block', color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>УРОВЕНЬ</label>
                  <input type="number" min="1" max="20" value={character.level} onChange={e => updateChar({ level: parseInt(e.target.value) || 1 })} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 14, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }} />
                </div>
                <div>
                  <label style={{ display: 'block', color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>ОПЫТ</label>
                  <input type="number" value={character.experience} onChange={e => updateChar({ experience: parseInt(e.target.value) || 0 })} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 14, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }} />
                </div>
              </div>
            </div>
          </div>

          <div>
            <h2 style={{ color: '#d4b896', fontSize: 14, fontFamily: 'Georgia, serif', letterSpacing: 1, margin: '0 0 16px', fontWeight: 600 }}>ХАРАКТЕРИСТИКИ</h2>
            <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid #292524', borderRadius: 8, padding: 16 }}>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
                {['strength', 'dexterity', 'constitution', 'intelligence', 'wisdom', 'charisma'].map(attr => {
                  const value = character[attr as keyof typeof character] as number;
                  const mod = ABILITY_MODS(value);
                  return (
                    <div key={attr} style={{ textAlign: 'center' }}>
                      <div style={{ color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', marginBottom: 6, letterSpacing: 1 }}>
                        {attr === 'strength' ? 'СИЛ' : attr === 'dexterity' ? 'ЛОВ' : attr === 'constitution' ? 'ТЛ' : attr === 'intelligence' ? 'ИНТ' : attr === 'wisdom' ? 'МДР' : 'ХР'}
                      </div>
                      <input
                        type="number"
                        min="1"
                        max="20"
                        value={value}
                        onChange={e => updateChar({ [attr]: parseInt(e.target.value) || 10 })}
                        style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 4, color: '#fef3c7', padding: '4px 6px', fontSize: 16, fontFamily: 'monospace', outline: 'none', boxSizing: 'border-box', textAlign: 'center', fontWeight: 700 }}
                      />
                      <div style={{ color: '#d97706', fontSize: 12, fontFamily: 'Georgia, serif', marginTop: 4 }}>
                        {mod >= 0 ? '+' : ''}{mod}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        <div style={{ marginBottom: 32 }}>
          <h2 style={{ color: '#d4b896', fontSize: 14, fontFamily: 'Georgia, serif', letterSpacing: 1, margin: '0 0 16px', fontWeight: 600 }}>СПАС-БРОСКИ</h2>
          <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid #292524', borderRadius: 8, padding: 16 }}>
            <textarea value={character.savesText} onChange={e => updateChar({ savesText: e.target.value })} placeholder="Стойкость +5, Рефлекс +3, Воля +4..." rows={2} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 13, fontFamily: 'Georgia, serif', outline: 'none', resize: 'vertical', boxSizing: 'border-box', lineHeight: 1.5 }} />
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 32, marginBottom: 32 }}>
          <div>
            <h2 style={{ color: '#d4b896', fontSize: 14, fontFamily: 'Georgia, serif', letterSpacing: 1, margin: '0 0 16px', fontWeight: 600 }}>ЗДОРОВЬЕ И ЗАЩИТА</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
                <div>
                  <label style={{ display: 'block', color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>ЧЗ</label>
                  <input type="number" value={character.hitPoints} onChange={e => updateChar({ hitPoints: parseInt(e.target.value) || 0 })} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 15, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }} />
                </div>
                <div>
                  <label style={{ display: 'block', color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>МАКС ЧЗ</label>
                  <input type="number" value={character.maxHitPoints} onChange={e => updateChar({ maxHitPoints: parseInt(e.target.value) || 10 })} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 15, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }} />
                </div>
              </div>
              <div>
                <label style={{ display: 'block', color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>КЛАСС БРОНИ</label>
                <input type="number" value={character.armorClass} onChange={e => updateChar({ armorClass: parseInt(e.target.value) || 10 })} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 15, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }} />
              </div>
            </div>
          </div>

          <div>
            <h2 style={{ color: '#d4b896', fontSize: 14, fontFamily: 'Georgia, serif', letterSpacing: 1, margin: '0 0 16px', fontWeight: 600 }}>НАВЫКИ И ИНВЕНТАРЬ</h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <div>
                <label style={{ display: 'block', color: '#78716c', fontSize: 11, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>НАВЫКИ</label>
                <textarea value={character.skillsText} onChange={e => updateChar({ skillsText: e.target.value })} placeholder="Боевое мастерство +5, Скрытность +3..." rows={3} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '8px 12px', fontSize: 13, fontFamily: 'Georgia, serif', outline: 'none', resize: 'vertical', boxSizing: 'border-box', lineHeight: 1.5 }} />
              </div>
            </div>
          </div>
        </div>

        <div>
          <h2 style={{ color: '#d4b896', fontSize: 14, fontFamily: 'Georgia, serif', letterSpacing: 1, margin: '0 0 16px', fontWeight: 600 }}>ИНВЕНТАРЬ</h2>
          <textarea value={character.inventory} onChange={e => updateChar({ inventory: e.target.value })} placeholder="Меч, щит, кольчуга, рюкзак, верёвка..." rows={3} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '12px 14px', fontSize: 14, fontFamily: 'Georgia, serif', outline: 'none', resize: 'vertical', boxSizing: 'border-box', lineHeight: 1.6 }} />
        </div>

        <div style={{ marginTop: 32 }}>
          <h2 style={{ color: '#d4b896', fontSize: 14, fontFamily: 'Georgia, serif', letterSpacing: 1, margin: '0 0 16px', fontWeight: 600 }}>ПРЕДЫСТОРИЯ</h2>
          <textarea value={character.backstory} onChange={e => updateChar({ backstory: e.target.value })} placeholder="Расскажите историю вашего персонажа..." rows={6} style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '12px 14px', fontSize: 14, fontFamily: 'Georgia, serif', outline: 'none', resize: 'vertical', boxSizing: 'border-box', lineHeight: 1.6 }} />
        </div>

        <div style={{ marginTop: 40 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <h2 style={{ color: '#d4b896', fontSize: 14, fontFamily: 'Georgia, serif', letterSpacing: 1, margin: 0, fontWeight: 600 }}>ЗАКЛИНАНИЯ</h2>
            <button
              onClick={() => {
                const newSpell: Spell = { id: crypto.randomUUID(), name: '', level: 0, school: '', castingTime: '', range: '', components: '', duration: '', description: '' };
                updateChar({ spells: [...(character.spells || []), newSpell] });
              }}
              style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 12px', background: 'rgba(59,130,246,0.15)', color: '#60a5fa', border: '1px solid rgba(59,130,246,0.2)', borderRadius: 6, cursor: 'pointer', fontSize: 12, fontFamily: 'Georgia, serif' }}
            >
              <Plus size={16} /> Добавить
            </button>
          </div>
          {!character.spells || character.spells.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px 20px', border: '2px dashed #292524', borderRadius: 12, color: '#57534e', fontFamily: 'Georgia, serif' }}>
              Нет заклинаний. Добавьте первое заклинание.
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 16 }}>
              {character.spells.map((spell, idx) => (
                <div key={spell.id} style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid #292524', borderRadius: 10, padding: 16 }}>
                  <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                    <input
                      type="text"
                      value={spell.name}
                      onChange={e => {
                        const updated = character.spells!.map((s, i) => i === idx ? { ...s, name: e.target.value } : s);
                        updateChar({ spells: updated });
                      }}
                      placeholder="Название заклинания"
                      style={{ flex: 1, background: '#0c0a09', border: '1px solid #44403c', borderRadius: 6, color: '#fef3c7', padding: '6px 10px', fontSize: 13, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }}
                    />
                    <button
                      onClick={() => {
                        const updated = character.spells!.filter((_, i) => i !== idx);
                        updateChar({ spells: updated });
                      }}
                      style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', width: 32, height: 32, background: 'rgba(127,29,29,0.5)', color: '#fca5a5', border: '1px solid #7f1d1d', borderRadius: 6, cursor: 'pointer' }}
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
                    <div>
                      <label style={{ display: 'block', color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>УРОВЕНЬ</label>
                      <input
                        type="number"
                        min="0"
                        max="9"
                        value={spell.level}
                        onChange={e => {
                          const updated = character.spells!.map((s, i) => i === idx ? { ...s, level: parseInt(e.target.value) || 0 } : s);
                          updateChar({ spells: updated });
                        }}
                        style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 4, color: '#fef3c7', padding: '4px 6px', fontSize: 12, fontFamily: 'monospace', outline: 'none', boxSizing: 'border-box', textAlign: 'center' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>ШКОЛА</label>
                      <input
                        type="text"
                        value={spell.school}
                        onChange={e => {
                          const updated = character.spells!.map((s, i) => i === idx ? { ...s, school: e.target.value } : s);
                          updateChar({ spells: updated });
                        }}
                        placeholder="Магия"
                        style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 4, color: '#fef3c7', padding: '4px 6px', fontSize: 12, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }}
                      />
                    </div>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 12 }}>
                    <div>
                      <label style={{ display: 'block', color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>ВРЕМЯ ДЕЙСТВИЯ</label>
                      <input
                        type="text"
                        value={spell.castingTime}
                        onChange={e => {
                          const updated = character.spells!.map((s, i) => i === idx ? { ...s, castingTime: e.target.value } : s);
                          updateChar({ spells: updated });
                        }}
                        placeholder="1 действие"
                        style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 4, color: '#fef3c7', padding: '4px 6px', fontSize: 12, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }}
                      />
                    </div>
                    <div>
                      <label style={{ display: 'block', color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>ДАЛЬНОСТЬ</label>
                      <input
                        type="text"
                        value={spell.range}
                        onChange={e => {
                          const updated = character.spells!.map((s, i) => i === idx ? { ...s, range: e.target.value } : s);
                          updateChar({ spells: updated });
                        }}
                        placeholder="30 футов"
                        style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 4, color: '#fef3c7', padding: '4px 6px', fontSize: 12, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }}
                      />
                    </div>
                  </div>
                  <div style={{ marginBottom: 12 }}>
                    <label style={{ display: 'block', color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>КОМПОНЕНТЫ</label>
                    <input
                      type="text"
                      value={spell.components}
                      onChange={e => {
                        const updated = character.spells!.map((s, i) => i === idx ? { ...s, components: e.target.value } : s);
                        updateChar({ spells: updated });
                      }}
                      placeholder="В, С, М"
                      style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 4, color: '#fef3c7', padding: '4px 6px', fontSize: 12, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }}
                    />
                  </div>
                  <div style={{ marginBottom: 12 }}>
                    <label style={{ display: 'block', color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>ДЛИТЕЛЬНОСТЬ</label>
                    <input
                      type="text"
                      value={spell.duration}
                      onChange={e => {
                        const updated = character.spells!.map((s, i) => i === idx ? { ...s, duration: e.target.value } : s);
                        updateChar({ spells: updated });
                      }}
                      placeholder="Мгновенно"
                      style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 4, color: '#fef3c7', padding: '4px 6px', fontSize: 12, fontFamily: 'Georgia, serif', outline: 'none', boxSizing: 'border-box' }}
                    />
                  </div>
                  <div>
                    <label style={{ display: 'block', color: '#78716c', fontSize: 10, fontFamily: 'Georgia, serif', marginBottom: 4, letterSpacing: 1 }}>ОПИСАНИЕ</label>
                    <textarea
                      value={spell.description}
                      onChange={e => {
                        const updated = character.spells!.map((s, i) => i === idx ? { ...s, description: e.target.value } : s);
                        updateChar({ spells: updated });
                      }}
                      placeholder="Описание эффекта заклинания..."
                      rows={3}
                      style={{ width: '100%', background: '#0c0a09', border: '1px solid #44403c', borderRadius: 4, color: '#fef3c7', padding: '4px 6px', fontSize: 12, fontFamily: 'Georgia, serif', outline: 'none', resize: 'vertical', boxSizing: 'border-box', lineHeight: 1.4 }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
