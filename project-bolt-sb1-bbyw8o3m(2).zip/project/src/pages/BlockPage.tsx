import { useEffect, useState } from 'react';
import { Block, Connection, BlockContent, AppView, BLOCK_COLORS } from '../lib/types';
import { db_blocks, db_connections, db_blockContents, initDb } from '../lib/db';
import ContentItem from '../components/block/ContentItem';

interface Props {
  projectId: string;
  blockId: string;
  onNavigate: (view: AppView) => void;
}

export default function BlockPage({ projectId, blockId, onNavigate }: Props) {
  const [block, setBlock] = useState<Block | null>(null);
  const [contents, setContents] = useState<BlockContent[]>([]);
  const [nextBlocks, setNextBlocks] = useState<{ connection: Connection; block: Block }[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingLabel, setEditingLabel] = useState(false);
  const [labelValue, setLabelValue] = useState('');

  useEffect(() => {
    loadData();
  }, [blockId]);

  async function loadData() {
    setLoading(true);
    await initDb();
    const blk = await db_blocks.getById(blockId);
    const cts = await db_blockContents.getByBlock(blockId);
    const conns = await db_connections.getByProject('').catch(() => []);

    setBlock(blk);
    setContents(cts || []);
    setLabelValue(blk?.label || '');

    if (blk) {
      const projectConns = await db_connections.getByProject(blk.project_id);
      const filtered = projectConns.filter(c => c.from_block_id === blockId);
      if (filtered.length > 0) {
        const pairs = [];
        for (const conn of filtered) {
          const nextBlock = await db_blocks.getById(conn.to_block_id);
          if (nextBlock) pairs.push({ connection: conn, block: nextBlock });
        }
        setNextBlocks(pairs);
      } else {
        setNextBlocks([]);
      }
    }
    setLoading(false);
  }

  async function saveLabel() {
    setEditingLabel(false);
    if (!labelValue.trim() || labelValue === block?.label) return;
    try {
      const { x, y } = block || { x: 0, y: 0 };
      await db_blocks.update(blockId, { label: labelValue.trim(), x, y });
      setBlock(prev => prev ? { ...prev, label: labelValue.trim() } : prev);
    } catch (err) {
      console.error(err);
    }
  }

  async function addContent(type: 'text' | 'image') {
    const maxPos = contents.length > 0 ? Math.max(...contents.map(c => c.position)) + 1 : 0;
    try {
      const data = await db_blockContents.create(blockId, { block_id: blockId, type, content: '', position: maxPos });
      setContents(prev => [...prev, data]);
    } catch (err) {
      console.error(err);
    }
  }

  async function deleteContent(id: string) {
    try {
      await db_blockContents.delete(id);
      setContents(prev => prev.filter(c => c.id !== id));
    } catch (err) {
      console.error(err);
    }
  }

  async function moveContent(id: string, direction: 'up' | 'down') {
    const idx = contents.findIndex(c => c.id === id);
    if (direction === 'up' && idx === 0) return;
    if (direction === 'down' && idx === contents.length - 1) return;

    const newContents = [...contents];
    const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
    [newContents[idx], newContents[swapIdx]] = [newContents[swapIdx], newContents[idx]];

    const updated = newContents.map((c, i) => ({ ...c, position: i }));
    setContents(updated);

    try {
      await Promise.all(
        updated.map(c => db_blockContents.update(c.id, { position: c.position }))
      );
    } catch (err) {
      console.error(err);
    }
  }

  if (loading) {
    return (
      <div style={{ minHeight: '100vh', background: '#0c0a09', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ color: '#78716c', fontFamily: 'Georgia, serif', fontSize: 18 }}>Загрузка...</div>
      </div>
    );
  }

  if (!block) {
    return (
      <div style={{ minHeight: '100vh', background: '#0c0a09', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ color: '#ef4444', fontFamily: 'Georgia, serif' }}>Блок не найден</div>
      </div>
    );
  }

  const colorDef = BLOCK_COLORS.find(c => c.value === block.color) || BLOCK_COLORS[2];

  return (
    <div style={{ minHeight: '100vh', background: '#0c0a09' }}>
      <div style={{
        position: 'sticky', top: 0, zIndex: 100,
        background: 'rgba(12,10,9,0.95)',
        borderBottom: '1px solid #292524',
        backdropFilter: 'blur(12px)',
      }}>
        <div style={{
          maxWidth: 800, margin: '0 auto',
          display: 'flex', alignItems: 'center', gap: 12,
          padding: '12px 24px',
        }}>
          <button
            onClick={() => onNavigate({ type: 'flowchart', projectId })}
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '7px 16px',
              background: 'rgba(255,255,255,0.04)',
              color: '#78716c', border: '1px solid #292524',
              borderRadius: 6, cursor: 'pointer',
              fontSize: 13, fontFamily: 'Georgia, serif',
              transition: 'all 0.15s', flexShrink: 0,
            }}
            onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.color = '#d4b896'; (e.currentTarget as HTMLButtonElement).style.borderColor = '#44403c'; }}
            onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.color = '#78716c'; (e.currentTarget as HTMLButtonElement).style.borderColor = '#292524'; }}
          >
            ← Блок-схема
          </button>

          <div style={{ width: 1, height: 24, background: '#292524' }} />

          <div
            style={{
              width: 12, height: 12, borderRadius: '50%',
              background: colorDef.border, flexShrink: 0,
            }}
          />

          {editingLabel ? (
            <input
              autoFocus
              value={labelValue}
              onChange={e => setLabelValue(e.target.value)}
              onBlur={saveLabel}
              onKeyDown={e => { if (e.key === 'Enter') saveLabel(); if (e.key === 'Escape') { setEditingLabel(false); setLabelValue(block.label); } }}
              style={{
                background: 'transparent', border: 'none',
                borderBottom: `1px solid ${colorDef.border}`,
                color: '#fef3c7', fontSize: 16,
                fontFamily: 'Georgia, serif', fontWeight: 700,
                outline: 'none', padding: '2px 0', flex: 1, minWidth: 0,
              }}
            />
          ) : (
            <h1
              onClick={() => setEditingLabel(true)}
              title="Нажмите для редактирования"
              style={{
                margin: 0, fontSize: 16, fontFamily: 'Georgia, serif',
                fontWeight: 700, color: '#fef3c7', cursor: 'text',
                flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
              }}
            >
              {block.label}
            </h1>
          )}
        </div>
      </div>

      <div style={{ maxWidth: 800, margin: '0 auto', padding: '40px 24px 80px' }}>
        <div style={{
          padding: '20px 24px',
          background: block.color,
          border: `1px solid ${colorDef.border}`,
          borderRadius: 12,
          marginBottom: 40,
          boxShadow: `0 0 40px rgba(0,0,0,0.5), inset 0 0 60px rgba(0,0,0,0.2)`,
        }}>
          <div style={{ color: colorDef.border, fontSize: 11, fontFamily: 'Georgia, serif', letterSpacing: 2, marginBottom: 8 }}>
            СЦЕНА
          </div>
          <div style={{ color: '#fef3c7', fontSize: 22, fontFamily: 'Georgia, serif', fontWeight: 700 }}>
            {block.label}
          </div>
        </div>

        <div style={{ marginBottom: 32 }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
            <h2 style={{ color: '#d4b896', fontFamily: 'Georgia, serif', fontSize: 15, margin: 0, fontWeight: 600, letterSpacing: 1 }}>
              КОНТЕНТ СЦЕНЫ
            </h2>
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                onClick={() => addContent('text')}
                style={{
                  padding: '7px 16px',
                  background: 'rgba(217,119,6,0.15)',
                  color: '#d97706', border: '1px solid rgba(217,119,6,0.3)',
                  borderRadius: 6, cursor: 'pointer',
                  fontSize: 13, fontFamily: 'Georgia, serif',
                }}
              >
                + Текст
              </button>
              <button
                onClick={() => addContent('image')}
                style={{
                  padding: '7px 16px',
                  background: 'rgba(59,130,246,0.1)',
                  color: '#60a5fa', border: '1px solid rgba(59,130,246,0.2)',
                  borderRadius: 6, cursor: 'pointer',
                  fontSize: 13, fontFamily: 'Georgia, serif',
                }}
              >
                + Изображение
              </button>
            </div>
          </div>

          {contents.length === 0 ? (
            <div style={{
              textAlign: 'center', padding: '40px 20px',
              border: '2px dashed #292524', borderRadius: 12,
              color: '#57534e', fontFamily: 'Georgia, serif',
            }}>
              Нет контента. Добавьте текст или изображения для этой сцены.
            </div>
          ) : (
            contents.map((item, idx) => (
              <ContentItem
                key={item.id}
                item={item}
                onUpdate={updated => setContents(prev => prev.map(c => c.id === updated.id ? updated : c))}
                onDelete={deleteContent}
                onMoveUp={(id) => moveContent(id, 'up')}
                onMoveDown={(id) => moveContent(id, 'down')}
                isFirst={idx === 0}
                isLast={idx === contents.length - 1}
              />
            ))
          )}
        </div>

        {nextBlocks.length > 0 && (
          <div style={{
            borderTop: '1px solid #292524',
            paddingTop: 32, marginTop: 32,
          }}>
            <h2 style={{
              color: '#d4b896', fontFamily: 'Georgia, serif',
              fontSize: 15, margin: '0 0 16px', fontWeight: 600, letterSpacing: 1,
            }}>
              СЛЕДУЮЩИЕ СЦЕНЫ
            </h2>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {nextBlocks.map(({ connection, block: nextBlock }) => {
                const nextColor = BLOCK_COLORS.find(c => c.value === nextBlock.color) || BLOCK_COLORS[2];
                return (
                  <button
                    key={connection.id}
                    onClick={() => onNavigate({ type: 'block', projectId, blockId: nextBlock.id })}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 14,
                      padding: '14px 20px',
                      background: nextBlock.color,
                      border: `1px solid ${nextColor.border}`,
                      borderRadius: 10, cursor: 'pointer',
                      textAlign: 'left',
                      transition: 'all 0.2s',
                      boxShadow: '0 4px 16px rgba(0,0,0,0.4)',
                    }}
                    onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.boxShadow = `0 4px 24px rgba(0,0,0,0.6), 0 0 0 1px ${nextColor.border}`; }}
                    onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.boxShadow = '0 4px 16px rgba(0,0,0,0.4)'; }}
                  >
                    {connection.label && (
                      <span style={{
                        background: 'rgba(0,0,0,0.4)',
                        color: nextColor.border,
                        border: `1px solid ${nextColor.border}`,
                        borderRadius: 4, padding: '2px 10px',
                        fontSize: 12, fontFamily: 'Georgia, serif',
                        whiteSpace: 'nowrap', flexShrink: 0,
                      }}>
                        {connection.label}
                      </span>
                    )}
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ color: '#fef3c7', fontFamily: 'Georgia, serif', fontWeight: 700, fontSize: 15 }}>
                        {nextBlock.label}
                      </div>
                    </div>
                    <span style={{ color: nextColor.border, fontSize: 18, flexShrink: 0 }}>→</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {nextBlocks.length === 0 && (
          <div style={{
            borderTop: '1px solid #292524',
            paddingTop: 28, marginTop: 28,
            textAlign: 'center',
          }}>
            <div style={{
              display: 'inline-block',
              padding: '12px 28px',
              background: 'rgba(217,119,6,0.08)',
              border: '1px solid rgba(217,119,6,0.2)',
              borderRadius: 8,
              color: '#d97706', fontFamily: 'Georgia, serif', fontSize: 14,
            }}>
              Конец ветки приключения
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
