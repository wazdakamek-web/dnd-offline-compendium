import { Project, Block, Connection, BlockContent } from './types';

const DB_NAME = 'dnd-adventure-db';
const DB_VERSION = 1;

let db: IDBDatabase | null = null;

export async function initDb(): Promise<IDBDatabase> {
  if (db) return db;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;

      const stores = [
        { name: 'projects', key: 'id' },
        { name: 'blocks', key: 'id' },
        { name: 'connections', key: 'id' },
        { name: 'block_contents', key: 'id' },
        { name: 'characters', key: 'id' },
      ];

      stores.forEach(store => {
        if (!database.objectStoreNames.contains(store.name)) {
          database.createObjectStore(store.name, { keyPath: store.key });
        }
      });
    };
  });
}

function getStore(storeName: string, mode: 'readonly' | 'readwrite' = 'readonly') {
  if (!db) throw new Error('Database not initialized');
  const tx = db.transaction(storeName, mode);
  return tx.objectStore(storeName);
}

export const db_projects = {
  async create(data: Omit<Project, 'id' | 'created_at' | 'updated_at'>): Promise<Project> {
    const database = await initDb();
    const id = crypto.randomUUID();
    const project: Project = {
      ...data,
      id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    const store = getStore('projects', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.add(project);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(project);
    });
  },

  async getAll(): Promise<Project[]> {
    await initDb();
    const store = getStore('projects', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result.sort((a: Project, b: Project) =>
        new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
      ));
    });
  },

  async getById(id: string): Promise<Project | null> {
    await initDb();
    const store = getStore('projects', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result || null);
    });
  },

  async update(id: string, data: Partial<Project>): Promise<void> {
    await initDb();
    const store = getStore('projects', 'readwrite');
    const existing = await this.getById(id);
    if (!existing) throw new Error('Project not found');
    const updated = { ...existing, ...data, updated_at: new Date().toISOString() };
    return new Promise((resolve, reject) => {
      const req = store.put(updated);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
  },

  async delete(id: string): Promise<void> {
    await initDb();
    await db_blocks.deleteByProject(id);
    await db_connections.deleteByProject(id);
    const store = getStore('projects', 'readwrite');
    await new Promise<void>((resolve, reject) => {
      const req = store.delete(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
  },
};

export const db_blocks = {
  async create(projectId: string, data: Omit<Block, 'id' | 'created_at'>): Promise<Block> {
    await initDb();
    const id = crypto.randomUUID();
    const block: Block = { ...data, id, created_at: new Date().toISOString() };
    const store = getStore('blocks', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.add(block);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        db_projects.update(projectId, {});
        resolve(block);
      };
    });
  },

  async getByProject(projectId: string): Promise<Block[]> {
    await initDb();
    const store = getStore('blocks', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        const results = req.result.filter((b: Block) => b.project_id === projectId);
        resolve(results.sort((a: Block, b: Block) =>
          new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        ));
      };
    });
  },

  async getById(id: string): Promise<Block | null> {
    await initDb();
    const store = getStore('blocks', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result || null);
    });
  },

  async update(id: string, data: Partial<Block>): Promise<void> {
    await initDb();
    const existing = await this.getById(id);
    if (!existing) throw new Error('Block not found');
    const updated = { ...existing, ...data };
    const store = getStore('blocks', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put(updated);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
  },

  async delete(id: string): Promise<void> {
    await initDb();
    const block = await this.getById(id);
    await db_blockContents.deleteByBlock(id);
    await db_connections.deleteByBlock(id);
    const store = getStore('blocks', 'readwrite');
    await new Promise<void>((resolve, reject) => {
      const req = store.delete(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
    if (block) {
      await db_projects.update(block.project_id, {});
    }
  },

  async deleteByProject(projectId: string): Promise<void> {
    const blocks = await this.getByProject(projectId);
    for (const block of blocks) {
      await db_blockContents.deleteByBlock(block.id);
      await db_connections.deleteByBlock(block.id);
      const store = getStore('blocks', 'readwrite');
      await new Promise<void>((resolve, reject) => {
        const req = store.delete(block.id);
        req.onerror = () => reject(req.error);
        req.onsuccess = () => resolve();
      });
    }
  },
};

export const db_connections = {
  async create(projectId: string, data: Omit<Connection, 'id' | 'created_at'>): Promise<Connection> {
    await initDb();
    const id = crypto.randomUUID();
    const connection: Connection = { ...data, id, created_at: new Date().toISOString() };
    const store = getStore('connections', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.add(connection);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        db_projects.update(projectId, {});
        resolve(connection);
      };
    });
  },

  async getByProject(projectId: string): Promise<Connection[]> {
    await initDb();
    const store = getStore('connections', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        const results = req.result.filter((c: Connection) => c.project_id === projectId);
        resolve(results.sort((a: Connection, b: Connection) =>
          new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        ));
      };
    });
  },

  async getById(id: string): Promise<Connection | null> {
    await initDb();
    const store = getStore('connections', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result || null);
    });
  },

  async delete(id: string): Promise<void> {
    await initDb();
    const conn = await this.getById(id);
    const store = getStore('connections', 'readwrite');
    await new Promise<void>((resolve, reject) => {
      const req = store.delete(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
    if (conn) {
      await db_projects.update(conn.project_id, {});
    }
  },

  async deleteByBlock(blockId: string): Promise<void> {
    await initDb();
    const store = getStore('connections', 'readonly');
    const conns = await new Promise<Connection[]>((resolve, reject) => {
      const req = store.getAll();
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        const filtered = req.result.filter((c: Connection) =>
          c.from_block_id === blockId || c.to_block_id === blockId
        );
        resolve(filtered);
      };
    });
    for (const conn of conns) {
      await this.delete(conn.id);
    }
  },

  async deleteByProject(projectId: string): Promise<void> {
    const conns = await this.getByProject(projectId);
    for (const conn of conns) {
      await this.delete(conn.id);
    }
  },
};

export const db_blockContents = {
  async create(blockId: string, data: Omit<BlockContent, 'id' | 'created_at'>): Promise<BlockContent> {
    await initDb();
    const id = crypto.randomUUID();
    const content: BlockContent = { ...data, id, created_at: new Date().toISOString() };
    const store = getStore('block_contents', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.add(content);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(content);
    });
  },

  async getByBlock(blockId: string): Promise<BlockContent[]> {
    await initDb();
    const store = getStore('block_contents', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onerror = () => reject(req.error);
      req.onsuccess = () => {
        const results = req.result.filter((c: BlockContent) => c.block_id === blockId);
        resolve(results.sort((a: BlockContent, b: BlockContent) => a.position - b.position));
      };
    });
  },

  async getById(id: string): Promise<BlockContent | null> {
    await initDb();
    const store = getStore('block_contents', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result || null);
    });
  },

  async update(id: string, data: Partial<BlockContent>): Promise<void> {
    await initDb();
    const existing = await this.getById(id);
    if (!existing) throw new Error('Content not found');
    const updated = { ...existing, ...data };
    const store = getStore('block_contents', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put(updated);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
  },

  async delete(id: string): Promise<void> {
    await initDb();
    const store = getStore('block_contents', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.delete(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
  },

  async deleteByBlock(blockId: string): Promise<void> {
    await initDb();
    const contents = await this.getByBlock(blockId);
    for (const content of contents) {
      await this.delete(content.id);
    }
  },
};

export interface Spell {
  id: string;
  name: string;
  level: number;
  school: string;
  castingTime: string;
  range: string;
  components: string;
  duration: string;
  description: string;
}

export interface Character {
  id: string;
  name: string;
  class: string;
  race: string;
  level: number;
  experience: number;
  hitPoints: number;
  maxHitPoints: number;
  armorClass: number;
  strength: number;
  dexterity: number;
  constitution: number;
  intelligence: number;
  wisdom: number;
  charisma: number;
  savesText: string;
  spells: Spell[];
  skillsText: string;
  inventory: string;
  backstory: string;
  created_at: string;
  updated_at: string;
}

export const db_characters = {
  async create(data: Omit<Character, 'id' | 'created_at' | 'updated_at'>): Promise<Character> {
    await initDb();
    const id = crypto.randomUUID();
    const character: Character = {
      ...data,
      id,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    const store = getStore('characters', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.add(character);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(character);
    });
  },

  async getAll(): Promise<Character[]> {
    await initDb();
    const store = getStore('characters', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.getAll();
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result.sort((a: Character, b: Character) =>
        new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()
      ));
    });
  },

  async getById(id: string): Promise<Character | null> {
    await initDb();
    const store = getStore('characters', 'readonly');
    return new Promise((resolve, reject) => {
      const req = store.get(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve(req.result || null);
    });
  },

  async update(id: string, data: Partial<Character>): Promise<void> {
    await initDb();
    const existing = await this.getById(id);
    if (!existing) throw new Error('Character not found');
    const updated = { ...existing, ...data, updated_at: new Date().toISOString() };
    const store = getStore('characters', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.put(updated);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
  },

  async delete(id: string): Promise<void> {
    await initDb();
    const store = getStore('characters', 'readwrite');
    return new Promise((resolve, reject) => {
      const req = store.delete(id);
      req.onerror = () => reject(req.error);
      req.onsuccess = () => resolve();
    });
  },
};

export interface DndCreature {
  id: string;
  name: string;
  type: string;
  challenge: number;
  ac: number;
  hp: string;
  speed: string;
  abilities: string;
  skills: string;
  senses: string;
  languages: string;
  traits: string;
  actions: string;
  reactions: string;
  description: string;
  created_at: string;
}

export interface DndItem {
  id: string;
  name: string;
  rarity: string;
  type: string;
  attunement: boolean;
  description: string;
  properties: string;
  created_at: string;
}

export interface DndSpell {
  id: string;
  name: string;
  level: number;
  school: string;
  casting_time: string;
  range: string;
  components: string;
  duration: string;
  description: string;
  classes: string;
  created_at: string;
}

import { supabase } from './supabase';

export const db_dnd = {
  creatures: {
    async search(query: string): Promise<DndCreature[]> {
      const { data, error } = await supabase
        .from('dnd_creatures')
        .select('*')
        .ilike('name', `%${query}%`)
        .limit(20);
      if (error) throw error;
      return data || [];
    },

    async getAll(): Promise<DndCreature[]> {
      const { data, error } = await supabase
        .from('dnd_creatures')
        .select('*')
        .order('name');
      if (error) throw error;
      return data || [];
    },

    async getById(id: string): Promise<DndCreature | null> {
      const { data, error } = await supabase
        .from('dnd_creatures')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  },

  items: {
    async search(query: string): Promise<DndItem[]> {
      const { data, error } = await supabase
        .from('dnd_items')
        .select('*')
        .ilike('name', `%${query}%`)
        .limit(20);
      if (error) throw error;
      return data || [];
    },

    async getAll(): Promise<DndItem[]> {
      const { data, error } = await supabase
        .from('dnd_items')
        .select('*')
        .order('name');
      if (error) throw error;
      return data || [];
    },

    async getById(id: string): Promise<DndItem | null> {
      const { data, error } = await supabase
        .from('dnd_items')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  },

  spells: {
    async search(query: string): Promise<DndSpell[]> {
      const { data, error } = await supabase
        .from('dnd_spells')
        .select('*')
        .ilike('name', `%${query}%`)
        .limit(20);
      if (error) throw error;
      return data || [];
    },

    async getAll(): Promise<DndSpell[]> {
      const { data, error } = await supabase
        .from('dnd_spells')
        .select('*')
        .order('name');
      if (error) throw error;
      return data || [];
    },

    async getById(id: string): Promise<DndSpell | null> {
      const { data, error } = await supabase
        .from('dnd_spells')
        .select('*')
        .eq('id', id)
        .maybeSingle();
      if (error) throw error;
      return data;
    },
  },
};
