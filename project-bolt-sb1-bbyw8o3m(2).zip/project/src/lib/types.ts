export interface Project {
  id: string;
  name: string;
  description: string;
  created_at: string;
  updated_at: string;
}

export interface Block {
  id: string;
  project_id: string;
  label: string;
  x: number;
  y: number;
  color: string;
  creature_id?: string;
  creature_name?: string;
  created_at: string;
}

export interface Connection {
  id: string;
  project_id: string;
  from_block_id: string;
  to_block_id: string;
  label: string;
  created_at: string;
}

export interface BlockContent {
  id: string;
  block_id: string;
  type: 'text' | 'image';
  content: string;
  position: number;
  created_at: string;
}

export type AppView =
  | { type: 'home' }
  | { type: 'flowchart'; projectId: string }
  | { type: 'block'; projectId: string; blockId: string }
  | { type: 'character-sheet'; characterId?: string };

export type Tool = 'select' | 'connect' | 'add';

export const BLOCK_WIDTH = 180;
export const BLOCK_HEIGHT = 64;

export const BLOCK_COLORS = [
  { label: 'Битва', value: '#7f1d1d', border: '#ef4444' },
  { label: 'Исследование', value: '#14532d', border: '#22c55e' },
  { label: 'Персонаж', value: '#1e3a5f', border: '#3b82f6' },
  { label: 'Сокровище', value: '#713f12', border: '#f59e0b' },
  { label: 'Загадка', value: '#3b0764', border: '#a855f7' },
  { label: 'Финал', value: '#1c1917', border: '#d6d3d1' },
];
