import { useState } from 'react';
import { AppView } from './lib/types';
import HomePage from './pages/HomePage';
import FlowChartPage from './pages/FlowChartPage';
import BlockPage from './pages/BlockPage';
import CharacterSheetPage from './pages/CharacterSheetPage';

export default function App() {
  const [view, setView] = useState<AppView>({ type: 'home' });

  if (view.type === 'home') {
    return <HomePage onNavigate={setView} />;
  }

  if (view.type === 'flowchart') {
    return <FlowChartPage projectId={view.projectId} onNavigate={setView} />;
  }

  if (view.type === 'block') {
    return <BlockPage projectId={view.projectId} blockId={view.blockId} onNavigate={setView} />;
  }

  if (view.type === 'character-sheet') {
    return <CharacterSheetPage characterId={view.characterId} onNavigate={setView} />;
  }

  return null;
}
