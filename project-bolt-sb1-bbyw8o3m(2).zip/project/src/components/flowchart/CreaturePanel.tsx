import { useState, useEffect } from 'react';
import { Block } from '../../lib/types';
import { db_dnd, DndCreature } from '../../lib/db';
import { X, Search, Plus } from 'lucide-react';

interface Props {
  blocks: Block[];
  onBlockUpdate: (blockId: string, updates: Partial<Block>) => void;
  onBlockRemove: (blockId: string) => void;
}

export default function CreaturePanel({ blocks, onBlockUpdate, onBlockRemove }: Props) {
  const [showSearch, setShowSearch] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [creatures, setCreatures] = useState<DndCreature[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedCreature, setSelectedCreature] = useState<DndCreature | null>(null);

  const creatureBlocks = blocks.filter(b => b.creature_id);

  async function searchCreatures(query: string) {
    if (query.length < 2) {
      setCreatures([]);
      return;
    }
    setLoading(true);
    try {
      const results = await db_dnd.creatures.search(query);
      setCreatures(results);
    } catch (err) {
      console.error('Error searching creatures:', err);
    }
    setLoading(false);
  }

  function addCreatureToBlock(creature: DndCreature) {
    const newBlock: Partial<Block> = {
      creature_id: creature.id,
      creature_name: creature.name,
      label: creature.name,
    };
    const firstBlock = creatureBlocks[0];
    if (firstBlock) {
      onBlockUpdate(firstBlock.id, newBlock);
    }
    setShowSearch(false);
    setSearchQuery('');
    setCreatures([]);
  }

  function removeCreatureFromBlock(blockId: string) {
    onBlockUpdate(blockId, {
      creature_id: undefined,
      creature_name: undefined,
    });
  }

  return (
    <div style={{
      position: 'absolute',
      right: 0,
      top: 0,
      bottom: 0,
      width: 320,
      background: 'linear-gradient(180deg, rgba(28,25,23,0.95) 0%, rgba(20,20,20,0.95) 100%)',
      borderLeft: '1px solid #292524',
      display: 'flex',
      flexDirection: 'column',
      zIndex: 10,
      backdropFilter: 'blur(8px)',
    }}>
      <div style={{
        padding: '16px',
        borderBottom: '1px solid #292524',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexShrink: 0,
      }}>
        <h3 style={{
          color: '#d4b896',
          fontSize: 14,
          fontFamily: 'Georgia, serif',
          margin: 0,
          letterSpacing: 1,
          fontWeight: 600,
        }}>
          СУЩЕСТВА
        </h3>
        <button
          onClick={() => setShowSearch(!showSearch)}
          style={{
            background: showSearch ? 'rgba(217,119,6,0.2)' : 'transparent',
            color: showSearch ? '#d97706' : '#78716c',
            border: '1px solid ' + (showSearch ? 'rgba(217,119,6,0.4)' : '#292524'),
            borderRadius: 6,
            padding: '4px 8px',
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            gap: 4,
            fontSize: 12,
            fontFamily: 'Georgia, serif',
          }}
        >
          <Plus size={16} />
        </button>
      </div>

      {showSearch && (
        <div style={{
          padding: '12px',
          borderBottom: '1px solid #292524',
          flexShrink: 0,
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: 8,
            background: '#0c0a09',
            border: '1px solid #44403c',
            borderRadius: 6,
            padding: '6px 10px',
            marginBottom: 8,
          }}>
            <Search size={16} style={{ color: '#78716c' }} />
            <input
              type="text"
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                searchCreatures(e.target.value);
              }}
              placeholder="Поиск существ..."
              style={{
                flex: 1,
                background: 'transparent',
                border: 'none',
                color: '#fef3c7',
                fontSize: 12,
                fontFamily: 'Georgia, serif',
                outline: 'none',
              }}
            />
          </div>

          {loading ? (
            <div style={{
              color: '#78716c',
              fontSize: 12,
              fontFamily: 'Georgia, serif',
              textAlign: 'center',
              padding: '8px 0',
            }}>
              Загрузка...
            </div>
          ) : creatures.length === 0 && searchQuery.length > 0 ? (
            <div style={{
              color: '#57534e',
              fontSize: 12,
              fontFamily: 'Georgia, serif',
              textAlign: 'center',
              padding: '8px 0',
            }}>
              Не найдено
            </div>
          ) : (
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: 4,
              maxHeight: 200,
              overflowY: 'auto',
            }}>
              {creatures.map(creature => (
                <button
                  key={creature.id}
                  onClick={() => addCreatureToBlock(creature)}
                  style={{
                    background: 'rgba(59,130,246,0.1)',
                    color: '#60a5fa',
                    border: '1px solid rgba(59,130,246,0.2)',
                    borderRadius: 4,
                    padding: '6px 8px',
                    cursor: 'pointer',
                    fontSize: 11,
                    fontFamily: 'Georgia, serif',
                    textAlign: 'left',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLButtonElement).style.background = 'rgba(59,130,246,0.2)';
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLButtonElement).style.background = 'rgba(59,130,246,0.1)';
                  }}
                >
                  <div style={{ fontWeight: 700 }}>{creature.name}</div>
                  <div style={{ fontSize: 10, color: '#7dd3fc' }}>CR {creature.challenge}</div>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <div style={{
        flex: 1,
        overflowY: 'auto',
        padding: '12px',
      }}>
        {creatureBlocks.length === 0 ? (
          <div style={{
            color: '#57534e',
            fontSize: 12,
            fontFamily: 'Georgia, serif',
            textAlign: 'center',
            padding: '24px 8px',
          }}>
            Нет добавленных существ. Нажмите + для поиска.
          </div>
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {creatureBlocks.map(block => (
              <div
                key={block.id}
                style={{
                  background: 'rgba(255,255,255,0.03)',
                  border: '1px solid #292524',
                  borderRadius: 8,
                  padding: 12,
                }}
              >
                <div style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  justifyContent: 'space-between',
                  marginBottom: 8,
                }}>
                  <div style={{
                    color: '#fef3c7',
                    fontSize: 13,
                    fontFamily: 'Georgia, serif',
                    fontWeight: 700,
                    flex: 1,
                  }}>
                    {block.creature_name}
                  </div>
                  <button
                    onClick={() => removeCreatureFromBlock(block.id)}
                    style={{
                      background: 'transparent',
                      border: 'none',
                      color: '#78716c',
                      cursor: 'pointer',
                      padding: 0,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: 16,
                    }}
                  >
                    <X size={16} />
                  </button>
                </div>
                <button
                  onClick={() => onBlockRemove(block.id)}
                  style={{
                    width: '100%',
                    padding: '6px 8px',
                    background: 'rgba(127,29,29,0.3)',
                    color: '#fca5a5',
                    border: '1px solid #7f1d1d',
                    borderRadius: 4,
                    cursor: 'pointer',
                    fontSize: 11,
                    fontFamily: 'Georgia, serif',
                    transition: 'all 0.2s',
                  }}
                  onMouseEnter={e => {
                    (e.currentTarget as HTMLButtonElement).style.background = 'rgba(127,29,29,0.5)';
                  }}
                  onMouseLeave={e => {
                    (e.currentTarget as HTMLButtonElement).style.background = 'rgba(127,29,29,0.3)';
                  }}
                >
                  Удалить блок
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
