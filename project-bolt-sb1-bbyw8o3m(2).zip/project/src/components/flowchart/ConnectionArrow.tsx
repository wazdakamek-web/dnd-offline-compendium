import { Connection, Block, BLOCK_WIDTH, BLOCK_HEIGHT } from '../../lib/types';

interface Props {
  connection: Connection;
  fromBlock: Block;
  toBlock: Block;
  isSelected: boolean;
  onClick: () => void;
}

function getConnectionPoints(from: Block, to: Block) {
  const HW = BLOCK_WIDTH / 2;
  const HH = BLOCK_HEIGHT / 2;
  const sx = from.x + HW;
  const sy = from.y + HH;
  const tx = to.x + HW;
  const ty = to.y + HH;

  const dx = tx - sx;
  const dy = ty - sy;
  const angle = Math.atan2(dy, dx);
  const absAngle = Math.abs(angle);

  let srcX: number, srcY: number, dstX: number, dstY: number;
  let c1x: number, c1y: number, c2x: number, c2y: number;

  if (absAngle < Math.PI / 4) {
    srcX = from.x + BLOCK_WIDTH; srcY = from.y + HH;
    dstX = to.x; dstY = to.y + HH;
    c1x = srcX + 60; c1y = srcY;
    c2x = dstX - 60; c2y = dstY;
  } else if (absAngle > 3 * Math.PI / 4) {
    srcX = from.x; srcY = from.y + HH;
    dstX = to.x + BLOCK_WIDTH; dstY = to.y + HH;
    c1x = srcX - 60; c1y = srcY;
    c2x = dstX + 60; c2y = dstY;
  } else if (angle > 0) {
    srcX = from.x + HW; srcY = from.y + BLOCK_HEIGHT;
    dstX = to.x + HW; dstY = to.y;
    c1x = srcX; c1y = srcY + 60;
    c2x = dstX; c2y = dstY - 60;
  } else {
    srcX = from.x + HW; srcY = from.y;
    dstX = to.x + HW; dstY = to.y + BLOCK_HEIGHT;
    c1x = srcX; c1y = srcY - 60;
    c2x = dstX; c2y = dstY + 60;
  }

  return { srcX, srcY, dstX, dstY, c1x, c1y, c2x, c2y };
}

function getLabelPosition(
  srcX: number, srcY: number,
  c1x: number, c1y: number,
  c2x: number, c2y: number,
  dstX: number, dstY: number
) {
  const t = 0.5;
  const mt = 1 - t;
  const x = mt * mt * mt * srcX + 3 * mt * mt * t * c1x + 3 * mt * t * t * c2x + t * t * t * dstX;
  const y = mt * mt * mt * srcY + 3 * mt * mt * t * c1y + 3 * mt * t * t * c2y + t * t * t * dstY;
  return { x, y };
}

export default function ConnectionArrow({ connection, fromBlock, toBlock, isSelected, onClick }: Props) {
  const { srcX, srcY, dstX, dstY, c1x, c1y, c2x, c2y } = getConnectionPoints(fromBlock, toBlock);
  const path = `M ${srcX} ${srcY} C ${c1x} ${c1y}, ${c2x} ${c2y}, ${dstX} ${dstY}`;
  const labelPos = getLabelPosition(srcX, srcY, c1x, c1y, c2x, c2y, dstX, dstY);
  const color = isSelected ? '#fbbf24' : '#d97706';

  return (
    <g onClick={(e) => { e.stopPropagation(); onClick(); }} style={{ cursor: 'pointer' }}>
      <path
        d={path}
        stroke="transparent"
        strokeWidth={16}
        fill="none"
      />
      <path
        d={path}
        stroke={color}
        strokeWidth={isSelected ? 3 : 2}
        fill="none"
        markerEnd="url(#arrowhead)"
        strokeDasharray={isSelected ? '6,3' : undefined}
        style={{ transition: 'stroke 0.2s' }}
      />
      {connection.label && (
        <g>
          <rect
            x={labelPos.x - 30}
            y={labelPos.y - 10}
            width={60}
            height={20}
            rx={4}
            fill="#1c1917"
            stroke={color}
            strokeWidth={1}
          />
          <text
            x={labelPos.x}
            y={labelPos.y + 4}
            textAnchor="middle"
            fill="#fef3c7"
            fontSize={11}
            fontFamily="serif"
          >
            {connection.label.length > 10 ? connection.label.slice(0, 10) + '…' : connection.label}
          </text>
        </g>
      )}
    </g>
  );
}
