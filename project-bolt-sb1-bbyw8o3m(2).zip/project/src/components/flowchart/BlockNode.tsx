import { useRef, useState } from 'react';
import { Block, BLOCK_WIDTH, BLOCK_HEIGHT, BLOCK_COLORS } from '../../lib/types';
import { db_blocks } from '../../lib/db';

interface Props {
  block: Block;
  isSelected: boolean;
  isConnectSource: boolean;
  tool: string;
  zoom: number;
  onSelect: () => void;
  onMove: (id: string, x: number, y: number) => void;
  onOpenPage: () => void;
  onLabelChange: (id: string, label: string) => void;
}

export default function BlockNode({
  block, isSelected, isConnectSource, tool, zoom,
  onSelect, onMove, onOpenPage, onLabelChange
}: Props) {
  const [editing, setEditing] = useState(false);
  const [editValue, setEditValue] = useState(block.label);
  const dragRef = useRef<{ startX: number; startY: number; origX: number; origY: number } | null>(null);
  const nodeRef = useRef<HTMLDivElement>(null);

  const colorDef = BLOCK_COLORS.find(c => c.value === block.color) || BLOCK_COLORS[2];

  function handleMouseDown(e: React.MouseEvent) {
    if (tool !== 'select') return;
    if (editing) return;
    e.stopPropagation();
    onSelect();
    dragRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      origX: block.x,
      origY: block.y,
    };

    const handleMouseMove = (ev: MouseEvent) => {
      if (!dragRef.current) return;
      const dx = (ev.clientX - dragRef.current.startX) / zoom;
      const dy = (ev.clientY - dragRef.current.startY) / zoom;
      onMove(block.id, dragRef.current.origX + dx, dragRef.current.origY + dy);
    };

    const handleMouseUp = async () => {
      if (!dragRef.current) return;
      await db_blocks.update(block.id, { x: block.x, y: block.y });
      dragRef.current = null;
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseup', handleMouseUp);
  }

  function handleClick(e: React.MouseEvent) {
    e.stopPropagation();
    if (tool === 'connect') {
      onSelect();
    } else if (tool === 'select') {
      onSelect();
    }
  }

  function handleDoubleClick(e: React.MouseEvent) {
    e.stopPropagation();
    if (tool === 'select') {
      setEditValue(block.label);
      setEditing(true);
    }
  }

  async function handleEditBlur() {
    setEditing(false);
    if (editValue.trim() && editValue !== block.label) {
      onLabelChange(block.id, editValue.trim());
      await db_blocks.update(block.id, { label: editValue.trim() });
    }
  }

  function handleEditKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter') handleEditBlur();
    if (e.key === 'Escape') { setEditing(false); setEditValue(block.label); }
  }

  const borderColor = isConnectSource
    ? '#fbbf24'
    : isSelected
    ? '#e2e8f0'
    : colorDef.border;

  const shadow = isSelected
    ? `0 0 0 2px ${borderColor}, 0 8px 32px rgba(0,0,0,0.6)`
    : `0 4px 16px rgba(0,0,0,0.5)`;

  return (
    <div
      ref={nodeRef}
      style={{
        position: 'absolute',
        left: block.x,
        top: block.y,
        width: BLOCK_WIDTH,
        height: BLOCK_HEIGHT,
        background: block.color,
        border: `2px solid ${borderColor}`,
        borderRadius: 8,
        boxShadow: shadow,
        cursor: tool === 'select' ? 'grab' : tool === 'connect' ? 'crosshair' : 'default',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        userSelect: 'none',
        transition: 'border-color 0.2s, box-shadow 0.2s',
        zIndex: isSelected ? 10 : 1,
      }}
      onMouseDown={handleMouseDown}
      onClick={handleClick}
      onDoubleClick={handleDoubleClick}
    >
      <div
        style={{
          width: 6,
          height: 6,
          borderRadius: '50%',
          background: block.creature_id ? '#f59e0b' : colorDef.border,
          position: 'absolute',
          top: 6,
          left: 8,
          opacity: 0.8,
        }}
        title={block.creature_id ? `Существо: ${block.creature_name}` : ''}
      />
      {editing ? (
        <input
          autoFocus
          value={editValue}
          onChange={e => setEditValue(e.target.value)}
          onBlur={handleEditBlur}
          onKeyDown={handleEditKeyDown}
          onClick={e => e.stopPropagation()}
          style={{
            width: '90%',
            background: 'rgba(0,0,0,0.5)',
            border: `1px solid ${colorDef.border}`,
            borderRadius: 4,
            color: '#fef3c7',
            textAlign: 'center',
            fontSize: 13,
            fontFamily: 'Georgia, serif',
            padding: '2px 4px',
            outline: 'none',
          }}
        />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2 }}>
          <span
            style={{
              color: '#fef3c7',
              fontSize: 13,
              fontFamily: 'Georgia, serif',
              fontWeight: 600,
              textAlign: 'center',
              padding: '0 10px',
              lineHeight: 1.2,
              wordBreak: 'break-word',
              maxWidth: '100%',
            }}
          >
            {block.label}
          </span>
          {block.creature_id && (
            <span
              style={{
                color: '#f59e0b',
                fontSize: 10,
                fontFamily: 'Georgia, serif',
                padding: '0 10px',
                opacity: 0.8,
              }}
            >
              👹 Существо
            </span>
          )}
        </div>
      )}
      {tool === 'select' && isSelected && !editing && (
        <button
          onClick={(e) => { e.stopPropagation(); onOpenPage(); }}
          style={{
            position: 'absolute',
            bottom: -28,
            left: '50%',
            transform: 'translateX(-50%)',
            background: colorDef.border,
            color: '#1c1917',
            border: 'none',
            borderRadius: 4,
            fontSize: 11,
            padding: '2px 8px',
            cursor: 'pointer',
            fontFamily: 'Georgia, serif',
            fontWeight: 700,
            whiteSpace: 'nowrap',
            zIndex: 20,
          }}
        >
          Открыть
        </button>
      )}
    </div>
  );
}
