import { useRef, useState, useCallback } from 'react';
import { Block, Connection, Tool, BLOCK_COLORS } from '../../lib/types';
import BlockNode from './BlockNode';
import ConnectionArrow from './ConnectionArrow';
import CreaturePanel from './CreaturePanel';
import { db_blocks, db_connections } from '../../lib/db';

interface Props {
  projectId: string;
  blocks: Block[];
  connections: Connection[];
  onBlocksChange: (blocks: Block[]) => void;
  onConnectionsChange: (connections: Connection[]) => void;
  onOpenBlock: (blockId: string) => void;
}

const GRID = 20;

export default function FlowchartCanvas({
  projectId, blocks, connections, onBlocksChange, onConnectionsChange, onOpenBlock
}: Props) {
  const [tool, setTool] = useState<Tool>('select');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<'block' | 'connection' | null>(null);
  const [connectSource, setConnectSource] = useState<string | null>(null);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [showColorPicker, setShowColorPicker] = useState(false);
  const [connLabelInput, setConnLabelInput] = useState('');
  const [showConnLabel, setShowConnLabel] = useState<{ fromId: string; toId: string } | null>(null);
  const canvasRef = useRef<HTMLDivElement>(null);
  const isPanningRef = useRef(false);
  const panStartRef = useRef({ x: 0, y: 0, panX: 0, panY: 0 });

  const selectedBlock = selectedType === 'block' ? blocks.find(b => b.id === selectedId) : null;
  const selectedConnection = selectedType === 'connection' ? connections.find(c => c.id === selectedId) : null;

  function getCanvasPos(clientX: number, clientY: number) {
    if (!canvasRef.current) return { x: 0, y: 0 };
    const rect = canvasRef.current.getBoundingClientRect();
    return {
      x: (clientX - rect.left - pan.x) / zoom,
      y: (clientY - rect.top - pan.y) / zoom,
    };
  }

  async function handleCanvasClick(e: React.MouseEvent) {
    if (isPanningRef.current) return;
    if (tool === 'add') {
      const pos = getCanvasPos(e.clientX, e.clientY);
      const x = Math.round(pos.x / GRID) * GRID - 90;
      const y = Math.round(pos.y / GRID) * GRID - 32;
      const color = BLOCK_COLORS[Math.floor(Math.random() * BLOCK_COLORS.length)].value;
      try {
        const data = await db_blocks.create(projectId, { project_id: projectId, label: 'Новый блок', x, y, color });
        onBlocksChange([...blocks, data]);
        setSelectedId(data.id);
        setSelectedType('block');
        setTool('select');
      } catch (err) {
        console.error(err);
      }
    } else {
      setSelectedId(null);
      setSelectedType(null);
      setConnectSource(null);
    }
  }

  function handleCanvasMouseDown(e: React.MouseEvent) {
    if (e.button !== 0) return;
    if (tool === 'select' && e.target === e.currentTarget) {
      isPanningRef.current = false;
      panStartRef.current = { x: e.clientX, y: e.clientY, panX: pan.x, panY: pan.y };

      const onMove = (ev: MouseEvent) => {
        const dx = ev.clientX - panStartRef.current.x;
        const dy = ev.clientY - panStartRef.current.y;
        if (Math.abs(dx) > 4 || Math.abs(dy) > 4) isPanningRef.current = true;
        setPan({ x: panStartRef.current.panX + dx, y: panStartRef.current.panY + dy });
      };
      const onUp = () => {
        window.removeEventListener('mousemove', onMove);
        window.removeEventListener('mouseup', onUp);
        setTimeout(() => { isPanningRef.current = false; }, 50);
      };
      window.addEventListener('mousemove', onMove);
      window.addEventListener('mouseup', onUp);
    }
  }

  function handleWheel(e: React.WheelEvent) {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    const newZoom = Math.min(Math.max(zoom * delta, 0.3), 3);
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    setPan(prev => ({
      x: mx - (mx - prev.x) * (newZoom / zoom),
      y: my - (my - prev.y) * (newZoom / zoom),
    }));
    setZoom(newZoom);
  }

  const handleBlockSelect = useCallback((blockId: string) => {
    if (tool === 'connect') {
      if (!connectSource) {
        setConnectSource(blockId);
        setSelectedId(blockId);
        setSelectedType('block');
      } else if (connectSource !== blockId) {
        setShowConnLabel({ fromId: connectSource, toId: blockId });
        setConnLabelInput('');
        setConnectSource(null);
        setSelectedId(null);
        setSelectedType(null);
      }
    } else {
      setSelectedId(blockId);
      setSelectedType('block');
      setConnectSource(null);
    }
  }, [tool, connectSource]);

  async function confirmConnection() {
    if (!showConnLabel) return;
    const { fromId, toId } = showConnLabel;
    const existing = connections.find(c => c.from_block_id === fromId && c.to_block_id === toId);
    if (!existing) {
      try {
        const data = await db_connections.create(projectId, { project_id: projectId, from_block_id: fromId, to_block_id: toId, label: connLabelInput });
        onConnectionsChange([...connections, data]);
      } catch (err) {
        console.error(err);
      }
    }
    setShowConnLabel(null);
  }

  async function deleteSelected() {
    if (selectedType === 'block' && selectedId) {
      try {
        await db_blocks.delete(selectedId);
        onBlocksChange(blocks.filter(b => b.id !== selectedId));
        onConnectionsChange(connections.filter(c => c.from_block_id !== selectedId && c.to_block_id !== selectedId));
        setSelectedId(null); setSelectedType(null);
      } catch (err) {
        console.error(err);
      }
    } else if (selectedType === 'connection' && selectedId) {
      try {
        await db_connections.delete(selectedId);
        onConnectionsChange(connections.filter(c => c.id !== selectedId));
        setSelectedId(null); setSelectedType(null);
      } catch (err) {
        console.error(err);
      }
    }
  }

  async function changeBlockColor(color: string) {
    if (!selectedBlock) return;
    try {
      await db_blocks.update(selectedBlock.id, { color });
      onBlocksChange(blocks.map(b => b.id === selectedBlock.id ? { ...b, color } : b));
      setShowColorPicker(false);
    } catch (err) {
      console.error(err);
    }
  }

  const handleBlockMove = useCallback((id: string, x: number, y: number) => {
    onBlocksChange(prev => prev.map(b => b.id === id ? { ...b, x, y } : b));
  }, [onBlocksChange]);

  const handleLabelChange = useCallback((id: string, label: string) => {
    onBlocksChange(prev => prev.map(b => b.id === id ? { ...b, label } : b));
  }, [onBlocksChange]);

  const toolBtn = (t: Tool, label: string) => (
    <button
      onClick={() => { setTool(t); setConnectSource(null); }}
      style={{
        padding: '6px 14px',
        background: tool === t ? '#d97706' : 'rgba(255,255,255,0.05)',
        color: tool === t ? '#1c1917' : '#d4b896',
        border: `1px solid ${tool === t ? '#d97706' : '#44403c'}`,
        borderRadius: 6,
        cursor: 'pointer',
        fontSize: 13,
        fontFamily: 'Georgia, serif',
        fontWeight: tool === t ? 700 : 400,
        transition: 'all 0.15s',
      }}
    >
      {label}
    </button>
  );

  async function handleBlockUpdate(blockId: string, updates: Partial<Block>) {
    const updated = blocks.map(b => b.id === blockId ? { ...b, ...updates } : b);
    onBlocksChange(updated);
    try {
      await db_blocks.update(blockId, updates);
    } catch (err) {
      console.error('Error updating block:', err);
    }
  }

  async function handleBlockRemove(blockId: string) {
    const updated = blocks.filter(b => b.id !== blockId);
    const connsToDelete = connections.filter(c => c.from_block_id === blockId || c.to_block_id === blockId);
    onBlocksChange(updated);
    onConnectionsChange(connections.filter(c => !connsToDelete.includes(c)));
    try {
      await db_blocks.delete(blockId);
      await Promise.all(connsToDelete.map(c => db_connections.delete(c.id)));
    } catch (err) {
      console.error('Error removing block:', err);
    }
  }

  return (
    <div style={{ display: 'flex', height: '100%', background: '#0c0a09', position: 'relative' }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '8px 16px',
          background: 'rgba(0,0,0,0.6)', borderBottom: '1px solid #292524',
          flexWrap: 'wrap',
        }}>
        <span style={{ color: '#78716c', fontSize: 12, fontFamily: 'Georgia, serif', marginRight: 4 }}>
          Инструменты:
        </span>
        {toolBtn('select', 'Выбор')}
        {toolBtn('add', 'Добавить блок')}
        {toolBtn('connect', 'Соединить')}
        <div style={{ width: 1, height: 24, background: '#44403c', margin: '0 4px' }} />
        <button
          onClick={deleteSelected}
          disabled={!selectedId}
          style={{
            padding: '6px 14px',
            background: selectedId ? 'rgba(127,29,29,0.5)' : 'rgba(255,255,255,0.02)',
            color: selectedId ? '#fca5a5' : '#57534e',
            border: `1px solid ${selectedId ? '#7f1d1d' : '#292524'}`,
            borderRadius: 6, cursor: selectedId ? 'pointer' : 'default',
            fontSize: 13, fontFamily: 'Georgia, serif', transition: 'all 0.15s',
          }}
        >
          Удалить
        </button>
        {selectedBlock && (
          <div style={{ position: 'relative' }}>
            <button
              onClick={() => setShowColorPicker(!showColorPicker)}
              style={{
                padding: '6px 14px',
                background: 'rgba(255,255,255,0.05)',
                color: '#d4b896',
                border: '1px solid #44403c',
                borderRadius: 6, cursor: 'pointer',
                fontSize: 13, fontFamily: 'Georgia, serif',
              }}
            >
              Цвет
            </button>
            {showColorPicker && (
              <div style={{
                position: 'absolute', top: 36, left: 0, zIndex: 100,
                background: '#1c1917', border: '1px solid #44403c',
                borderRadius: 8, padding: 8, display: 'flex', flexDirection: 'column', gap: 4, minWidth: 140,
              }}>
                {BLOCK_COLORS.map(c => (
                  <button
                    key={c.value}
                    onClick={() => changeBlockColor(c.value)}
                    style={{
                      display: 'flex', alignItems: 'center', gap: 8,
                      background: selectedBlock.color === c.value ? 'rgba(255,255,255,0.1)' : 'transparent',
                      border: 'none', borderRadius: 4, padding: '4px 8px',
                      cursor: 'pointer', color: '#d4b896', fontSize: 13, fontFamily: 'Georgia, serif',
                    }}
                  >
                    <span style={{ width: 16, height: 16, borderRadius: 4, background: c.border, display: 'inline-block' }} />
                    {c.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 8, alignItems: 'center' }}>
          <span style={{ color: '#57534e', fontSize: 12, fontFamily: 'monospace' }}>
            {Math.round(zoom * 100)}%
          </span>
          <button onClick={() => setZoom(1)} style={{ padding: '4px 10px', background: 'rgba(255,255,255,0.05)', color: '#78716c', border: '1px solid #292524', borderRadius: 4, cursor: 'pointer', fontSize: 12 }}>
            Сбросить
          </button>
        </div>
      </div>

      {tool === 'connect' && (
        <div style={{
          padding: '6px 16px', background: 'rgba(217,119,6,0.1)', borderBottom: '1px solid #44403c',
          color: '#fbbf24', fontSize: 12, fontFamily: 'Georgia, serif',
        }}>
          {connectSource
            ? 'Нажмите на блок назначения для создания соединения'
            : 'Нажмите на исходный блок'}
        </div>
      )}
      {tool === 'add' && (
        <div style={{
          padding: '6px 16px', background: 'rgba(30,58,95,0.2)', borderBottom: '1px solid #44403c',
          color: '#93c5fd', fontSize: 12, fontFamily: 'Georgia, serif',
        }}>
          Нажмите на холст чтобы добавить блок
        </div>
      )}

        <div
          ref={canvasRef}
          style={{
            flex: 1, overflow: 'hidden', position: 'relative',
            cursor: tool === 'select' ? 'default' : tool === 'add' ? 'crosshair' : 'crosshair',
            backgroundImage: `radial-gradient(circle, #292524 1px, transparent 1px)`,
            backgroundSize: `${20 * zoom}px ${20 * zoom}px`,
            backgroundPosition: `${pan.x}px ${pan.y}px`,
          }}
          onMouseDown={handleCanvasMouseDown}
          onClick={handleCanvasClick}
          onWheel={handleWheel}
        >
        <div style={{
          position: 'absolute', left: 0, top: 0,
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
          transformOrigin: '0 0',
          width: 4000, height: 4000,
        }}>
          <svg
            style={{ position: 'absolute', left: 0, top: 0, width: '100%', height: '100%', overflow: 'visible', pointerEvents: 'none' }}
          >
            <defs>
              <marker id="arrowhead" markerWidth="10" markerHeight="7" refX="9" refY="3.5" orient="auto">
                <polygon points="0 0, 10 3.5, 0 7" fill="#d97706" />
              </marker>
            </defs>
            <g style={{ pointerEvents: 'all' }}>
              {connections.map(conn => {
                const from = blocks.find(b => b.id === conn.from_block_id);
                const to = blocks.find(b => b.id === conn.to_block_id);
                if (!from || !to) return null;
                return (
                  <ConnectionArrow
                    key={conn.id}
                    connection={conn}
                    fromBlock={from}
                    toBlock={to}
                    isSelected={selectedId === conn.id && selectedType === 'connection'}
                    onClick={() => { setSelectedId(conn.id); setSelectedType('connection'); }}
                  />
                );
              })}
            </g>
          </svg>

          {blocks.map(block => (
            <BlockNode
              key={block.id}
              block={block}
              isSelected={selectedId === block.id && selectedType === 'block'}
              isConnectSource={connectSource === block.id}
              tool={tool}
              zoom={zoom}
              onSelect={() => handleBlockSelect(block.id)}
              onMove={handleBlockMove}
              onOpenPage={() => onOpenBlock(block.id)}
              onLabelChange={handleLabelChange}
            />
          ))}
        </div>
        </div>
      </div>

      <CreaturePanel
        blocks={blocks}
        onBlockUpdate={handleBlockUpdate}
        onBlockRemove={handleBlockRemove}
      />

      {showConnLabel && (
        <div style={{
          position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200,
        }}>
          <div style={{
            background: '#1c1917', border: '1px solid #d97706',
            borderRadius: 12, padding: 28, minWidth: 320, boxShadow: '0 20px 60px rgba(0,0,0,0.8)',
          }}>
            <div style={{ color: '#fef3c7', fontSize: 16, fontFamily: 'Georgia, serif', fontWeight: 700, marginBottom: 16 }}>
              Метка соединения
            </div>
            <input
              autoFocus
              value={connLabelInput}
              onChange={e => setConnLabelInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && confirmConnection()}
              placeholder="Например: Да / Нет / Атака..."
              style={{
                width: '100%', background: '#0c0a09', border: '1px solid #44403c',
                borderRadius: 6, color: '#fef3c7', padding: '8px 12px',
                fontSize: 14, fontFamily: 'Georgia, serif', outline: 'none',
                boxSizing: 'border-box',
              }}
            />
            <div style={{ display: 'flex', gap: 10, marginTop: 16, justifyContent: 'flex-end' }}>
              <button
                onClick={() => setShowConnLabel(null)}
                style={{ padding: '8px 18px', background: 'transparent', color: '#78716c', border: '1px solid #44403c', borderRadius: 6, cursor: 'pointer', fontFamily: 'Georgia, serif' }}
              >
                Отмена
              </button>
              <button
                onClick={confirmConnection}
                style={{ padding: '8px 18px', background: '#d97706', color: '#1c1917', border: 'none', borderRadius: 6, cursor: 'pointer', fontFamily: 'Georgia, serif', fontWeight: 700 }}
              >
                Создать
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
