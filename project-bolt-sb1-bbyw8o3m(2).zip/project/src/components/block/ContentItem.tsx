import { useState } from 'react';
import { BlockContent } from '../../lib/types';
import { db_blockContents } from '../../lib/db';

interface Props {
  item: BlockContent;
  onUpdate: (updated: BlockContent) => void;
  onDelete: (id: string) => void;
  onMoveUp: (id: string) => void;
  onMoveDown: (id: string) => void;
  isFirst: boolean;
  isLast: boolean;
}

export default function ContentItem({ item, onUpdate, onDelete, onMoveUp, onMoveDown, isFirst, isLast }: Props) {
  const [editing, setEditing] = useState(item.content === '' && item.type === 'text');
  const [value, setValue] = useState(item.content);

  async function saveText() {
    setEditing(false);
    if (value !== item.content) {
      try {
        await db_blockContents.update(item.id, { content: value });
        onUpdate({ ...item, content: value });
      } catch (err) {
        console.error(err);
      }
    }
  }

  async function handleImageChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 5 * 1024 * 1024) {
      alert('Файл слишком большой (макс. 5MB)');
      return;
    }
    const reader = new FileReader();
    reader.onload = async (ev) => {
      const dataUrl = ev.target?.result as string;
      try {
        await db_blockContents.update(item.id, { content: dataUrl });
        onUpdate({ ...item, content: dataUrl });
      } catch (err) {
        console.error(err);
      }
    };
    reader.readAsDataURL(file);
  }

  const buttonStyle = (color?: string): React.CSSProperties => ({
    padding: '4px 10px',
    background: color ? `rgba(${color},0.15)` : 'rgba(255,255,255,0.05)',
    color: color ? `rgb(${color})` : '#78716c',
    border: `1px solid ${color ? `rgba(${color},0.3)` : '#292524'}`,
    borderRadius: 4,
    cursor: 'pointer',
    fontSize: 12,
    fontFamily: 'Georgia, serif',
  });

  return (
    <div style={{
      background: 'rgba(255,255,255,0.03)',
      border: '1px solid #292524',
      borderRadius: 8,
      marginBottom: 12,
      overflow: 'hidden',
    }}>
      <div style={{
        display: 'flex', gap: 6, alignItems: 'center',
        padding: '6px 10px',
        background: 'rgba(0,0,0,0.3)',
        borderBottom: '1px solid #1c1917',
      }}>
        <span style={{ color: '#57534e', fontSize: 11, fontFamily: 'Georgia, serif' }}>
          {item.type === 'text' ? 'Текст' : 'Изображение'}
        </span>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
          {!isFirst && (
            <button onClick={() => onMoveUp(item.id)} style={buttonStyle()}>▲</button>
          )}
          {!isLast && (
            <button onClick={() => onMoveDown(item.id)} style={buttonStyle()}>▼</button>
          )}
          {item.type === 'text' && !editing && (
            <button onClick={() => setEditing(true)} style={buttonStyle('214,119,6')}>Изменить</button>
          )}
          <button onClick={() => onDelete(item.id)} style={buttonStyle('239,68,68')}>✕</button>
        </div>
      </div>

      <div style={{ padding: 12 }}>
        {item.type === 'text' ? (
          editing ? (
            <div>
              <textarea
                autoFocus
                value={value}
                onChange={e => setValue(e.target.value)}
                style={{
                  width: '100%', minHeight: 120,
                  background: '#0c0a09', border: '1px solid #44403c',
                  borderRadius: 6, color: '#e7e5e4', padding: '10px 12px',
                  fontSize: 15, fontFamily: 'Georgia, serif', outline: 'none',
                  lineHeight: 1.6, resize: 'vertical', boxSizing: 'border-box',
                }}
              />
              <div style={{ display: 'flex', gap: 8, marginTop: 8, justifyContent: 'flex-end' }}>
                <button onClick={() => { setEditing(false); setValue(item.content); }} style={buttonStyle()}>Отмена</button>
                <button
                  onClick={saveText}
                  style={{ ...buttonStyle('217,119,6'), background: '#d97706', color: '#1c1917', fontWeight: 700 }}
                >
                  Сохранить
                </button>
              </div>
            </div>
          ) : (
            <p style={{
              color: '#e7e5e4', fontSize: 15, fontFamily: 'Georgia, serif',
              lineHeight: 1.7, margin: 0, whiteSpace: 'pre-wrap',
            }}>
              {item.content || <span style={{ color: '#57534e', fontStyle: 'italic' }}>Пусто. Нажмите «Изменить».</span>}
            </p>
          )
        ) : (
          <div>
            {item.content ? (
              <img
                src={item.content}
                alt="Контент"
                style={{
                  maxWidth: '100%', borderRadius: 6,
                  border: '1px solid #292524', display: 'block',
                }}
              />
            ) : (
              <label style={{
                display: 'flex', flexDirection: 'column', alignItems: 'center',
                justifyContent: 'center', gap: 8, minHeight: 100,
                border: '2px dashed #44403c', borderRadius: 6, cursor: 'pointer',
                color: '#57534e', fontFamily: 'Georgia, serif',
              }}>
                <span style={{ fontSize: 28 }}>🖼</span>
                <span>Нажмите для загрузки изображения</span>
                <input type="file" accept="image/*" onChange={handleImageChange} style={{ display: 'none' }} />
              </label>
            )}
            {item.content && (
              <label style={{ marginTop: 8, display: 'inline-block' }}>
                <button
                  onClick={() => document.getElementById(`img-input-${item.id}`)?.click()}
                  style={buttonStyle('214,119,6')}
                >
                  Заменить
                </button>
                <input id={`img-input-${item.id}`} type="file" accept="image/*" onChange={handleImageChange} style={{ display: 'none' }} />
              </label>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
